#PowerShell
#Script to deploy azure function apps to the azure environment
#It prompts for the user credential who account will be used for deploying the azure function apps
Write-Host "Installing Azure 7.11.0 version of Arcsight Azure Monitor Eventhub Connector"
Write-Host "The script does the following:"
Write-Host "1. Creates an Arc Sight Active Directory application, assigns the role of 'Website Contributor' to the application and creates the secret key for the application."
Write-Host "2. Checks if the following exist and creates them in the following sequence if they do not exist:"
Write-Host "   a. Resource group"
Write-Host "   b. Storage Account"
Write-Host "   c. Storage Container"
Write-Host "   d. Function apps resources"
Write-Host "   e. Event hub namesspace"
Write-Host "   f. EventHubs"
Write-Host "   g. Sets the function apps application settings"
Write-Host "   h. EventHub consumer group"
Write-Host "   i. EventHub SAS Policy"
Write-Host "3. Streams Active Directory and Activity logs to the corresponding event hubs."
Write-Host "4. Deploys the supplied artifacts to the Azure functions."


#Read the properties file
$file_content = Get-Content ".\app.properties" -raw
$file_content = [Regex]::Escape($file_content)
$file_content = $file_content -replace "(\\r)?\\n", [Environment]::NewLine
$configuration = ConvertFrom-StringData($file_content)

$resourceGroupName=$configuration.'resourceGroupName'
$functionAppName1=$configuration.'functionAppName1'
$functionAppName2=$configuration.'functionAppName2'
$location=$configuration.'location'
$storageAccount=$configuration.'storageAccount'
$containerName=$configuration.'containerName'
$funcartifact1=$configuration.'funcartifact1'
$funcartifact2=$configuration.'funcartifact2'
$eventRetentionDays=$configuration.'eventRetentionDays'
$hubPartitionCount=$configuration.'hubPartitionCount'
$servicePlan=$configuration.'servicePlan'
$servicePlanName=$configuration.'servicePlanName'
$Azure = Get-AzureRmEnvironment 'AzureCloud'

#Connect to Azure resource manager account
Remove-AzureRmAccount  -EA SilentlyContinue
Add-AzureRmAccount

#Open the window with all the available subscriptions for selection
$Subscription = (Get-AzureRmSubscription | Out-GridView -Title "Selectt the auth profile" -PassThru)

#Retrieve the subscription id for later use
$subscriptionId =$Subscription.SubscriptionId;
$tentantID = $Subscription.TenantId;
$contentType = "application/json";
$authBase="https://management.azure.com/subscriptions/"+$subscriptionId
$authBaseURL=$authBase+"/resourceGroups/"+$resourceGroupName+"/providers/Microsoft.Web/sites/";
$apiVersion="?api-version="+$configuration.'apiVersion';

# Select Subscription Function
Function Subscription {
	Get-AzureRmSubscription -SubscriptionId $subscriptionId | Select-AzureRmSubscription
}

#Set the subscription for this script to operate
Set-AzureRMContext -Subscription $subscriptionId -NAME $Subscription.Name
#Get the resource group with name supplied in the app.properties
$resourceGroup = Get-AzureRmResourceGroup | Where-Object { $_.ResourceGroupName -eq $resourceGroupName }

if ($resourceGroup -eq $null)
{
	Write-Host "Resource group does not exist." -ForegroundColor red -BackgroundColor white
	Write-Host "Creating resource group" $resourceGroup
	New-AzureRmResourceGroup -Name $resourceGroupName -Location $location -force
}
$plan
if($servicePlan -eq 'Appserviceplan'){
	$plan=Get-AzureRmAppServicePlan -Name $servicePlanName -ResourceGroupName $resourceGroupName
	if ($plan -eq $null)
	{
		Write-Host "Plan name "$servicePlan" does not exist."
		Write-Host "Creating plan name" $servicePlan
		New-AzureRmAppServicePlan -ResourceGroupName $resourceGroupName -Name $servicePlanName -Location $location -Tier $configuration.'servicePlanTier' -NumberofWorkers $configuration.'servicePlanNumberofWorkers' -WorkerSize $configuration.'servicePlanWorkerSize'
	}
	$plan=Get-AzureRmAppServicePlan -Name $servicePlanName -ResourceGroupName $resourceGroupName
}
#Get the function app with name supplied in the app.properties
$functionAppResource1 = Get-AzureRmResource | Where-Object { $_.Name -eq $functionAppName1 -And $_.ResourceType -eq "Microsoft.Web/Sites" }

if ($functionAppResource1 -eq $null)
{
	#Create the function app1 as it doesn't exist
	if($servicePlan -ne 'Appserviceplan'){
		New-AzureRmResource -ResourceType "Microsoft.Web/Sites" -Name $functionAppName1 -kind "functionapp" -Location $location -ResourceGroupName $resourceGroupName -Properties @{} -force
	}else{
		New-AzureRmResource -ResourceType "Microsoft.Web/Sites" -Name $functionAppName1 -kind "functionapp" -Location $location -ResourceGroupName $resourceGroupName -Properties @{serverFarmId = $plan.Id} -force
	}
}
#Get the function app with name supplied in the app.properties
$functionAppResource2 = Get-AzureRmResource | Where-Object { $_.Name -eq $functionAppName2 -And $_.ResourceType -eq "Microsoft.Web/Sites" }

if ($functionAppResource2 -eq $null)
{
	#Create the function app2 as it doesn't exist
	if($servicePlan -ne 'Appserviceplan'){
		New-AzureRmResource -ResourceType "Microsoft.Web/Sites" -Name $functionAppName2 -kind "functionapp" -Location $location -ResourceGroupName $resourceGroupName -Properties @{} -force
	}else{
		New-AzureRmResource -ResourceType "Microsoft.Web/Sites" -Name $functionAppName2 -kind "functionapp" -Location $location -ResourceGroupName $resourceGroupName -Properties @{serverFarmId = $plan.Id} -force
	}
}
$upgrade="N"
if($functionAppResource2 -ne $null -and $functionAppResource1 -ne $null){
	Write-Host "Function apps exist."
	$upgrade = Read-Host "Do you want to upgrade the binary only for function apps? Y/N"
	while("yes","no","y","n" -notcontains $upgrade)
	{
		$upgrade = Read-Host "Do you want to upgrade the binary only for function apps? Y/N"
	}
}

#Function that invokes the Azure RM Invoke-RestMethod based on the parameters & writes the result to the console
function Invoke-ASRestMethod($functionURL, $jsonDATA, $method){
	$Result =Invoke-RestMethod -Method $method -Uri $functionURL -ContentType $contentType -Headers $requestHeader -Body $jsonDATA;
	Write-Host $Result
}

#Function that invokes the Azure RM Invoke-WebRequest based on the parameters & returns the result to the caller
function Invoke-ASWebRequest($functionURL, $jsonDATA, $method){
	$Result =Invoke-WebRequest -Method $method -Uri $functionURL -ContentType $contentType -Headers $requestHeader -Body $jsonDATA;
	return $Result
}

#Function which retrieve the auth token to access the Azure management rest API
Function RESTAPI-Auth {
	# Load ADAL Azure AD Authentication Library Assemblies
	Subscription
	$adTenant = $Subscription.TenantId
	# Client ID for Azure PowerShell
	$clientId = "1950a258-227b-4e31-a9cf-717495945fc2"
	# Set redirect URI for Azure PowerShell
	$redirectUri = "urn:ietf:wg:oauth:2.0:oob"
	# Set Resource URI to Azure Service Management API | @marckean
	#$resourceAppIdURIASM = "https://management.core.windows.net/"
	$resourceAppIdURIARM = "https://management.azure.com/"
	 
	# Authenticate and Acquire Token
	 
	# Set Authority to Azure AD Tenant
	$authority = "https://login.windows.net/$adTenant"
	# Create Authentication Context tied to Azure AD Tenant
	$authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
	# Acquire token
	#$global:authResultASM = $authContext.AcquireToken($resourceAppIdURIASM, $clientId, $redirectUri, "Auto")
	$global:authResultARM = $authContext.AcquireToken($resourceAppIdURIARM, $clientId, $redirectUri, "Auto")
}

# Call the functions above
RESTAPI-Auth # To Logon to Rest and get an an auth key
$authHeader = $global:authResultARM.CreateAuthorizationHeader();

# Set HTTP request headers to include Authorization header
$requestHeader = @{
	"Accept"="application/json"
	"Authorization" = $authHeader
}

if("no","n" -contains $upgrade){

	#Get the storage account with name supplied in the app.properties
	$storageAccounts = Get-AzureRmStorageAccount -ResourceGroupName $resourceGroupName -AccountName $storageAccount -EA SilentlyContinue

	if ($storageAccounts -eq $null)
	{
		$storageAccounts = Get-AzureRmStorageAccountNameAvailability -Name $storageAccount
		if($storageAccounts.NameAvailable)
		{
			Write-Host "Storage account does not exist." -ForegroundColor red -BackgroundColor white
			Write-Host "Creating storage account "$storageAccounts
			New-AzureRmStorageAccount -ResourceGroupName $resourceGroupName -AccountName $storageAccount -Location $location -SkuName "Standard_LRS"
		}else {
			Write-Host "Unable to create storage account, Reason: "$storageAccounts.Reason "Message: " $storageAccounts.Message -ForegroundColor red -BackgroundColor white
			Write-Host "Take appropriate action and deploy the function app again."
			break;
		}
	}

	$storageAccountData=Get-AzureRmStorageAccount -ResourceGroupName  $resourceGroupName -AccountName $storageAccount
	#Retrieve the storage context which is required for storage container
	$ctx = $storageAccountData.Context
	#Get the storage container with name supplied in the app.properties
	$storageContainerData = Get-AzureStorageContainer -Context $ctx | Where-Object { $_.Name -eq $configuration.'containerName' }
	if($storageContainerData -eq $null)
	{
		Write-Host "Storage Container "$storageContainerData" does not exist." -ForegroundColor red -BackgroundColor white
		Write-Host "Creating storage Container " $storageContainerData 
		New-AzureStorageContainer -Name $configuration.'containerName' -Permission Container -Context $ctx
	}


	#This function sets the Azure ADApplication secret key description & value based on the ad application id passed
	function Grant-OAuth2PermissionsToApp{
		Param(
			[Parameter(Mandatory=$true)]$azureAppId, #application ID of the azure application you wish to admin-consent to
			[Parameter(Mandatory=$true)]$AzureAppSecretValue,
			[Parameter(Mandatory=$true)]$AzureAppSecretValueDesc
		)
		$context = Get-AzureRmContext
		#Retrieve the token to access azure active directory rest services API
		try
		{
			$tokens = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.TokenCache.ReadItems()
		}
		catch
		{
			$tokens = [Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache]::DefaultShared.ReadItems()
		}

		$azureEnvironment=Get-AzureRmEnvironment 'AzureCloud'
		$refreshToken = $tokens |
			Where Resource -EQ $azureEnvironment.ActiveDirectoryServiceEndpointResourceId |
			Where IsMultipleResourceRefreshToken -EQ $true |
			Where DisplayableId -EQ $context.Account.Id |
			Sort ExpiresOn |
			Select -Last 1 -ExpandProperty RefreshToken

		#Write-Host "Refresh Token: "$refreshToken
		
		$context = Get-AzureRmContext
		$tenantId = $context.Tenant.Id
		$body="grant_type=refresh_token&refresh_token=$($refreshToken)&resource=74658136-14ec-4630-ad9b-26e160ff0fc6"
		$url="https://login.windows.net/$($tenantId)/oauth2/token"
		$apiToken = Invoke-RestMethod "https://login.windows.net/$tenantId/oauth2/token" -Method POST -Body $body -ContentType 'application/x-www-form-urlencoded'
		$header = @{
		'Authorization' = 'Bearer ' + $apiToken.access_token
		'X-Requested-With'= 'XMLHttpRequest'
		'x-ms-client-request-id'= [guid]::NewGuid()
		'x-ms-correlation-id' = [guid]::NewGuid()
		'Content-Type'='application/json'
		}
		$url="https://main.iam.ad.ext.azure.com/api/RegisteredApplications/"+$azureAppId+"?expand={expand}"
		#The JSON data as payload for the REST call to set the AD application secret key
		$data='{
		"objectId":"'+$azureAppId+'",
		"passwordCredentials":[
			{
			"endDate":"2299-12-30T18:30:00.000Z",
			"keyId":"'+[guid]::NewGuid()+'",
			"value":"'+$AzureAppSecretValue+'",
			"passwordDescription":"'+$AzureAppSecretValueDesc+'"
			}
		],
		"keyCredentials":[]
		}';
		Try{
			#Actual rest call to set the application secret key
			Start-Sleep 30;
			$Result=Invoke-WebRequest -Uri $url -Headers $header -Body $data -Method PUT -EA SilentlyContinue
		}Catch{
			$ErrorMessage = $_.Exception.Message
			Write-Host "Error while creating the secret key. We will try again. The error is: "$ErrorMessage -ForegroundColor red -BackgroundColor white
			#It is observed that sometime the rest call throws NotFound error during the 1st call, so we catch the exception & make a delay. Then again call the same REST API
			Start-Sleep 30;
			Try{
				$Result=Invoke-WebRequest -Uri $url -Headers $header -Body $data -Method PUT -EA SilentlyContinue
			}Catch{
				$ErrorMessage = $_.Exception.Message
				Write-Host "Again error while creating the secret key. Please do manual configuration after the deployment completes. The error is: "$ErrorMessage -ForegroundColor red -BackgroundColor white
				return;
			}
		}
		$json = $Result | ConvertFrom-Json 
		#As the password credentials is been returned for the 1st time & its not available on subsequent request, so we print it to console for reference
		Write-Host 'Please capture this password for future use. Password credential: '$json.'passwordCredentials'.'value'
		$retStr=[string]$json.'passwordCredentials'.'value'
		return $retStr;
	}
	$redirectUri="http://localhost/"+[guid]::NewGuid()
	#Get the Azure active directory application
	$appDetail=Get-AzureRmADApplication -DisplayName $configuration.'adapplicationName' | Select-Object -first 1

	if ( $appDetail -eq $null){
		#Create the Azure active directory application
		$appDetail=New-AzureRmADApplication -DisplayName $configuration.'adapplicationName' -HomePage $configuration.'homePage' -IdentifierUris $redirectUri
		$i = 0
		While ($i -lt 10)
		 {
		  $appDetailNew=Get-AzureRmADApplication -DisplayName $configuration.'adapplicationName' | Select-Object -first 1
		  if($appDetailNew -ne $null){
			break;
		  }
		  $i++ 
		  Start-Sleep 10;
		 }
	}else{
		$appDetail=Get-AzureRmADApplication -DisplayName $configuration.'adapplicationName' | Select-Object -first 1
		Remove-AzureRmADApplication -ObjectId $appDetail.ObjectId.Guid -Force
		#Create the Azure active directory application
		$appDetail=New-AzureRmADApplication -DisplayName $configuration.'adapplicationName' -HomePage $configuration.'homePage' -IdentifierUris $redirectUri
		$i = 0
		While ($i -lt 10)
		 {
		  $appDetailNew=Get-AzureRmADApplication -DisplayName $configuration.'adapplicationName' | Select-Object -first 1
		  if($appDetailNew -ne $null){
			break;
		  }
		  $i++ 
		  Start-Sleep 10;
		 }
	}
	#Call the Grant-OAuth2PermissionsToApp method to set the secret key & retrieve the returned encripted key
	$secretAppKeyString=Grant-OAuth2PermissionsToApp $appDetail.ObjectId.Guid $configuration.'adapplicationSecret' $configuration.'adapplicationSecretDesc'
	#Assign role to the ArcSight Azure Application
	$appDetail=Get-AzureRmADApplication -DisplayName $configuration.'adapplicationName' | Select-Object -first 1
	$sp=Get-AzureRmADServicePrincipal -ApplicationId $appDetail.ApplicationId.Guid
	if ( $sp -eq $null){
		$sp=New-AzureRmADServicePrincipal -ApplicationId $appDetail.ApplicationId.Guid
		$i = 0
		While ($i -lt 10)
		 {
		  $spDetl=Get-AzureRmADServicePrincipal -ApplicationId $appDetail.ApplicationId.Guid
		  if($spDetl -ne $null){
			break;
		  }
		  $i++ 
		  Start-Sleep 10;
		 }
	}
	$scope="/subscriptions/"+$subscriptionId
	Write-Host "Service principal value: " $sp.Id.Guid "Scope " $scope
	#Retrieve the Azure Ad service principal Id
	$objID=[String]$sp.Id.Guid
	#Retrieve the role related to the Azure ad service principal
	$wcRoleDetl=Get-AzureRmRoleAssignment -ObjectId $objID -RoleDefinitionName "Website Contributor"
	if($wcRoleDetl -eq $null){
		#Assign the role to the Azure ad service principal
		Try{
			#Actual rest call to set the application secret key
			Start-Sleep 20;
			New-AzureRmRoleAssignment -ObjectId $sp.Id.Guid -RoleDefinitionName "Website Contributor" -Scope $scope -EA SilentlyContinue
			Write-Host "The "$configuration.'adapplicationName'" has been assigned the Website Contributor role"
		}Catch{
			$ErrorMessage = $_.Exception.Message
			Write-Host "Error while assigning role to the Azure ad service principal. The installer will try again. The error is: "$ErrorMessage -ForegroundColor red -BackgroundColor white
			#It is observed that sometime the rest call throws NotFound error during the 1st call, so we catch the exception & make a delay. Then again call the same REST API
			Start-Sleep 20;
			Try{
				New-AzureRmRoleAssignment -ObjectId $sp.Id.Guid -RoleDefinitionName "Website Contributor" -Scope $scope -EA SilentlyContinue
				Write-Host "The "$configuration.'adapplicationName'" has been assigned the Website Contributor role"
			}Catch{
				$ErrorMessage = $_.Exception.Message
				Write-Host "Error occured again while assigning role to the Azure ad service principal. Please proceed with manual configuration. The error is: "$ErrorMessage -ForegroundColor red -BackgroundColor white
			}
		}
	}else{
		Write-Host "The "$configuration.'adapplicationName'" already has 'Website Contributor' role"
	}

	#Retrieve the azure storage account key
	$keys = Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroupName -AccountName $storageAccount
	#Filter the Key1 from the list of keys retrieve in last step
	$accountKey = $keys | Where-Object { $_.KeyName -eq "Key1" } | Select Value
	#Build the storage connection string
	$storageAccountConnectionString = "DefaultEndpointsProtocol=https;AccountName=" + $storageAccount + ";AccountKey=" + $accountKey.Value

	$Namespace=$configuration.'eventhubNamespaceName'

	###### Check for event hub name space

	# Query to see if the namespace currently exists
	$CurrentNamespace = Get-AzureRMEventHubNamespace -ResourceGroupName $resourceGroupName -NamespaceName $Namespace -EA SilentlyContinue

	# Check if the namespace already exists or needs to be create
	if ($CurrentNamespace)
	{
		Write-Host "The namespace $Namespace already exists in the $location region."
		# Report what was found
		Get-AzureRMEventHubNamespace -ResourceGroupName $resourceGroupName -NamespaceName $Namespace
	}
	else
	{
	$CurrentNamespace = Test-AzureRmEventhubName -Namespace $Namespace

	# Check if the namespace already exists or needs to be create
		if (!$CurrentNamespace.NameAvailable)
		{
			Write-Host "The namespace $Namespace is not available. Reason: "$CurrentNamespace.Reason "Message "$CurrentNamespace.Message -ForegroundColor red -BackgroundColor white
			Write-Host "Please choose a different namespace and try again" -ForegroundColor red -BackgroundColor white
			# Report what was found
			break;
		}else{
			Write-Host "The "$Namespace" namespace does not exist."
			Write-Host "Creating the "$Namespace" namespace in the "$location" region."
			#Create the namespace as it was not exist
			New-AzureRmEventHubNamespace -ResourceGroupName $resourceGroupName -NamespaceName $Namespace -Location $location
			#Wait, as the creation of event hub takes a little time
			Start-Sleep 15
		}
	}

	# Create an event hub
	# Check if event hub already exists
	function CheckFor-EventHub($EventHubName, $Location){
		$CurrentEH
		Try
		{
			$CurrentEH = Get-AzureRMEventHub -ResourceGroupName $resourceGroupName -NamespaceName $Namespace -EventHubName $EventHubName -EA SilentlyContinue
		}Catch{}
		
		if($CurrentEH)
		{
			Write-Host "The event hub $EventHubName already exists in the $Location region."
			# Report what was found
			Get-AzureRmEventHub -ResourceGroupName $resourceGroupName -NamespaceName $Namespace -EventHubName $EventHubName
		}
		else
		{
			Write-Host "The $EventHubName event hub does not exist." -ForegroundColor red -BackgroundColor white
			Write-Host "Creating the $EventHubName event hub in the $Location region."
			#Create the event hub as it doesn't found
			New-AzureRmEventHub -ResourceGroupName $resourceGroupName -NamespaceName $Namespace -EventHubName $EventHubName -MessageRetentionInDays $eventRetentionDays -PartitionCount $hubPartitionCount
			$CurrentEH = Get-AzureRmEventHub -ResourceGroupName $resourceGroupName -NamespaceName $Namespace -EventHubName $EventHubName
		}
	}

	#Check if consumer group already exists
	function CheckFor-ConsumerGroup($ResGrpName, $EventHubName, $ConsumerGroupName, $Location){

		$CurrentCG = Get-AzureRmEventHubConsumerGroup -ResourceGroupName $ResGrpName -NamespaceName $Namespace -EventHubName $EventHubName -ConsumerGroupName $ConsumerGroupName -ErrorAction Ignore

		if($CurrentCG)
		{
			Write-Host "The consumer group $ConsumerGroupName in event hub $EventHubName already exists in the $Location region."
			# Report what was found
			Get-AzureRmEventHubConsumerGroup -ResourceGroupName $ResGrpName -NamespaceName $Namespace -EventHubName $EventHubName -EA SilentlyContinue
		}
		else
		{
			Write-Host "The $ConsumerGroupName consumer group does not exist." -ForegroundColor red -BackgroundColor white
			Write-Host "Creating the $ConsumerGroupName consumer group in the $Location region..."
			New-AzureRmEventHubConsumerGroup -ResourceGroupName $ResGrpName -NamespaceName $Namespace -EventHubName $EventHubName -ConsumerGroupName $ConsumerGroupName -EA SilentlyContinue
			$CurrentCG = Get-AzureRmEventHubConsumerGroup -ResourceGroupName $ResGrpName -NamespaceName $Namespace -EventHubName $EventHubName
		}
	}
	#Now check for the 4 event hubs & create them if required
	$ConsumerGroupName=$configuration.'consumerGroupName'
	Write-Host 'Consumer group '$ConsumerGroupName
	$AdEventHubName = $configuration.'adEventHubName'
	CheckFor-EventHub $AdEventHubName $location
	CheckFor-ConsumerGroup $resourceGroupName $AdEventHubName $ConsumerGroupName $location
	$DiagnosticEventHubName = $configuration.'diagnosticEventHubName'
	CheckFor-EventHub $DiagnosticEventHubName $location
	CheckFor-ConsumerGroup $resourceGroupName $DiagnosticEventHubName $ConsumerGroupName $location
	$ActivityEventHubName = $configuration.'activityEventHubName'
	CheckFor-EventHub $ActivityEventHubName $location
	CheckFor-ConsumerGroup $resourceGroupName $ActivityEventHubName $ConsumerGroupName $location

	$SasKeyName=$configuration.'sasKeyName'
	#Retrieve the sas policy associated with the eventhub namespace
	$EvtHubSasKeyDtl = Get-AzureRmEventHubKey -ResourceGroupName $resourceGroupName -Namespace $Namespace -Name $SasKeyName -EA SilentlyContinue

	if($EvtHubSasKeyDtl)
	{
		Write-Host "The SAS Policy "$SasKeyName" exists."
	}
	else
	{
		Write-Host "The SAS Policy does not exist." -ForegroundColor red -BackgroundColor white
		#Create the sas policy associated with the eventhub namespace
		New-AzureRmEventHubAuthorizationRule -ResourceGroupName $resourceGroupName -NamespaceName $Namespace -AuthorizationRuleName $SasKeyName -Rights @("Manage","Listen","Send")
		#Retrieve the sas key detail for getting the eventhub names space connection string
		$EvtHubSasKeyDtl = Get-AzureRmEventHubKey -ResourceGroupName $resourceGroupName -Namespace $Namespace -Name $SasKeyName
	}
	#Build the app settings for the azure cloud function
	$AppSettings = @{
		"AzureWebJobsDashboard"=$storageAccountConnectionString;
		"AzureWebJobsStorage"=$storageAccountConnectionString;
		"connectorhostname"=$configuration.'connectorhostname';
		"connectorport"=$configuration.'connectorport';
		"shareReference"=$functionAppName1;
		"functionDirectoryReference"=$functionAppName1;
		"keyStoreFileName"=$configuration.'keyStoreFileName';
		"keyStorePassword"=$configuration.'keyStorePassword';
		"tlsVersion"=$configuration.'tlsVersion';
		"eventhubNamespaceName"=$configuration.'eventhubNamespaceName';
		"adEventHubName"=$configuration.'adEventHubName';
		"diagnosticEventHubName"=$configuration.'diagnosticEventHubName';
		"activityEventHubName"=$configuration.'activityEventHubName';
		"sasKeyName"=$configuration.'sasKeyName';
		"EventHubConnection"=$EvtHubSasKeyDtl.PrimaryConnectionString;
		"consumerGroupName"=$ConsumerGroupName;
		"FUNCTIONS_EXTENSION_VERSION"=$configuration.'FUNCTIONS_EXTENSION_VERSION';
		"FUNCTIONS_WORKER_RUNTIME"=$configuration.'FUNCTIONS_WORKER_RUNTIME';
		"DebugMode"=$configuration.'debugMode';
		"logging.storageaccount.enabled"=$configuration.'loggingStorageaccountEnabled';
		"logging.level"=$configuration.'loggingLevel';
		"logging.dir"='cloudfunction';
	}
		
	$str = $AppSettings | Out-String
	Write-Host $str
	#Set the application setting for the azure cloud function
	Set-AzureRMWebApp -Name $functionAppName1 -ResourceGroupName $resourceGroupName -AppSettings $AppSettings

	#Build the app settings for the azure monitor function
	$adAppId=[string]$appDetail.ApplicationId.Guid;
	if($secretAppKeyString -ne $null){
		$AppSettings = @{
			"AzureWebJobsDashboard"=$storageAccountConnectionString;
			"AzureWebJobsStorage"=$storageAccountConnectionString;
			"connectorhostname"=$configuration.'connectorhostname';
			"connectorport"=$configuration.'connectorport';
			"keyStoreFileName"=$configuration.'keyStoreFileName';
			"keyStorePassword"=$configuration.'keyStorePassword';
			"tlsVersion"=$configuration.'tlsVersion';
			"shareReference"=$functionAppName1;
			"functionDirectoryReference"=$functionAppName1;
			"adapplication"=$adAppId;
			"adapplicationsecret"=$secretAppKeyString;
			"subscriptionid"=$Subscription.SubscriptionId;
			"resourcegroup"=$resourceGroupName;
			"tenantid"=$Subscription.TenantId;
			"arcsightfunction"=$functionAppName1;
			"FUNCTIONS_EXTENSION_VERSION"=$configuration.'FUNCTIONS_EXTENSION_VERSION';
			"FUNCTIONS_WORKER_RUNTIME"=$configuration.'FUNCTIONS_WORKER_RUNTIME';
			"DebugMode"=$configuration.'debugMode';
			"logging.storageaccount.enabled"=$configuration.'loggingStorageaccountEnabled';
			"logging.level"=$configuration.'loggingLevel';
			"logging.dir"='monitorfunction';
		}
	}
	else{
		$AppSettings = @{
			"AzureWebJobsDashboard"=$storageAccountConnectionString;
			"AzureWebJobsStorage"=$storageAccountConnectionString;
			"connectorhostname"=$configuration.'connectorhostname';
			"connectorport"=$configuration.'connectorport';
			"keyStoreFileName"=$configuration.'keyStoreFileName';
			"keyStorePassword"=$configuration.'keyStorePassword';
			"tlsVersion"=$configuration.'tlsVersion';
			"shareReference"=$functionAppName1;
			"functionDirectoryReference"=$functionAppName1;
			"adapplication"=$adAppId;
			"subscriptionid"=$Subscription.SubscriptionId;
			"resourcegroup"=$resourceGroupName;
			"tenantid"=$Subscription.TenantId;
			"arcsightfunction"=$functionAppName1;
			"FUNCTIONS_EXTENSION_VERSION"=$configuration.'FUNCTIONS_EXTENSION_VERSION';
			"FUNCTIONS_WORKER_RUNTIME"=$configuration.'FUNCTIONS_WORKER_RUNTIME';
			"DebugMode"=$configuration.'debugMode';
			"logging.storageaccount.enabled"=$configuration.'loggingStorageaccountEnabled';
			"logging.level"=$configuration.'loggingLevel';	
			"logging.dir"='monitorfunction';			
		}
	}
	$str = $AppSettings | Out-String
	Write-Host $str
	#Build the app settings for the azure monitor function
	Set-AzureRMWebApp -Name $functionAppName2 -ResourceGroupName $resourceGroupName -AppSettings $AppSettings

	#Subscribe the Azure Active directory logs to insights-activedirectory-logs event hub start
	$AdEventSubscriberName = $configuration.'adEventHubSubscriberName'
	$url3 = "https://management.azure.com/providers/microsoft.aadiam/diagnosticSettings/"+$AdEventSubscriberName+"?api-version="+$configuration.'adAPIVersion';
	$data = '{
		"id": "/providers/microsoft.aadiam/providers/microsoft.insights/diagnosticSettings/'+$AdEventSubscriberName+'",	
		"name": "'+$AdEventSubscriberName+'",	
		"properties": {	
			"logs": [{	
					"category": "AuditLogs",	
					"enabled": true,	
					"retentionPolicy": {	
						"days": 0,	
						"enabled": false	
					}	
				}, {	
					"category": "SignInLogs",	
					"enabled": true,	
					"retentionPolicy": {	
						"days": 0,	
						"enabled": false	
					}	
				}	
			],	
			"metrics": [],	
			"eventHubAuthorizationRuleId": "/subscriptions/'+$subscriptionId+'/resourceGroups/'+$resourceGroupName+'/providers/Microsoft.EventHub/namespaces/'+$Namespace+'/authorizationrules/'+$SasKeyName+'",	
			"eventHubName": "'+$AdEventHubName+'"
		}	
	}'

	$Result = Invoke-ASWebRequest $url3 $data "PUT"
	if($Result.StatusCode -eq 200){
			Write-Host "Successfully streamed the Azure Active Directory Audit and SignIn events to "$AdEventHubName " event hub."
		}
		else{
			Write-Host "Unable to stream Azure Active Directory events to "$AdEventHubName ". Please proceed with manual configuration.";
	}
	#Subscribe the Azure active directory logs to insights-activedirectory-logs event hub end

	#Subscribe the Azure Activity logs to insights-operational-logs event hub start
	$logLocation=$configuration.'activityLogSubscriptionLoc'
	$url3=$authBase+"/providers/microsoft.insights/logprofiles/default"+"?api-version="+$configuration.'activityLogAPIVersion';
	$data = '{
		"id": null,
		"location": null,
		"name": null,
		"properties": {
			"categories": ["Write", "Delete", "Action"],
			"storageAccountId": null,
			"locations": '+$logLocation+',
			"retentionPolicy": {
				"enabled": true,
				"days": '+$eventRetentionDays+'
			},
			"serviceBusRuleId": "/subscriptions/'+$subscriptionId+'/resourceGroups/'+$resourceGroupName+'/providers/Microsoft.EventHub/namespaces/'+$Namespace+'/authorizationrules/'+$SasKeyName+'"
		},
		"tags": null
	}'

	$Result = Invoke-ASWebRequest $url3 $data "PUT"
	if($Result.StatusCode -eq 200){
			Write-Host "Successfully streamed the Azure Activity Log events to "$configuration.'activityEventHubName' " event hub."
		}
		else{
			Write-Host "Unable to stream Azure Activity Log events to "$configuration.'activityEventHubName' ". Please proceed with manual configuration.";
	}
	#Subscribe the Azure Activity logs to insights-operational-logs event hub end

	#Set Function apps standard configuration data start
	$url3 = $authBaseURL+$functionAppName1+$apiVersion;
	$data = '{"kind":"functionapp","properties":{"enabled":true,"hostNameSslStates":[{"name":"'+$functionAppName1+'.azurewebsites.net","sslState":"Disabled","hostType":"Standard"},{"name":"'+$functionAppName1+'.scm.azurewebsites.net","sslState":"Disabled","hostType":"Repository"}],"reserved":false,"siteConfig":{},"scmSiteAlsoStopped":false,"clientAffinityEnabled":true,"clientCertEnabled":false,"hostNamesDisabled":false,"containerSize":1536,"dailyMemoryTimeQuota":0,"httpsOnly":false},"location":"'+$location+'"}';

	Invoke-ASRestMethod $url3 $data "PUT"

	$url3=$authBaseURL+$functionAppName1+"/config/web"+$apiVersion
	$data = '{"properties":{"numberOfWorkers":1,"defaultDocuments":["Default.htm","Default.html","Default.asp","index.htm","index.html","iisstart.htm","default.aspx","index.php"],"netFrameworkVersion":"v4.0","phpVersion":"5.6","pythonVersion":"","nodeVersion":"","linuxFxVersion":"","requestTracingEnabled":false,"remoteDebuggingEnabled":false,"httpLoggingEnabled":false,"logsDirectorySizeLimit":35,"detailedErrorLoggingEnabled":false,"publishingUsername":"$'+$functionAppName1+'","scmType":"None","use32BitWorkerProcess":true,"webSocketsEnabled":false,"alwaysOn":false,"appCommandLine":"","managedPipelineMode":"Integrated","virtualApplications":[{"virtualPath":"/","physicalPath":"site\\wwwroot","preloadEnabled":false}],"loadBalancing":"LeastRequests","experiments":{"rampUpRules":[]},"autoHealEnabled":false,"vnetName":"","cors":{"allowedOrigins":["https://functions.azure.com","https://functions-staging.azure.com","https://functions-next.azure.com"]},"localMySqlEnabled":false}}';

	Invoke-ASRestMethod $url3 $data "PUT"

	$url3 = $authBaseURL+$functionAppName2+$apiVersion
	$data = '{"kind":"functionapp","properties":{"enabled":true,"hostNameSslStates":[{"name":"'+$functionAppName2+'.azurewebsites.net","sslState":"Disabled","hostType":"Standard"},{"name":"'+$functionAppName2+'.scm.azurewebsites.net","sslState":"Disabled","hostType":"Repository"}],"reserved":false,"siteConfig":{},"scmSiteAlsoStopped":false,"clientAffinityEnabled":true,"clientCertEnabled":false,"hostNamesDisabled":false,"containerSize":1536,"dailyMemoryTimeQuota":0,"httpsOnly":false},"location":"'+$location+'"}';

	Invoke-ASRestMethod $url3 $data "PUT"

	$url3=$authBaseURL+$functionAppName2+"/config/web"+$apiVersion
	$data = '{"properties":{"numberOfWorkers":1,"defaultDocuments":["Default.htm","Default.html","Default.asp","index.htm","index.html","iisstart.htm","default.aspx","index.php"],"netFrameworkVersion":"v4.0","phpVersion":"5.6","pythonVersion":"","nodeVersion":"","linuxFxVersion":"","requestTracingEnabled":false,"remoteDebuggingEnabled":false,"httpLoggingEnabled":false,"logsDirectorySizeLimit":35,"detailedErrorLoggingEnabled":false,"publishingUsername":"$'+$functionAppName2+'","scmType":"None","use32BitWorkerProcess":true,"webSocketsEnabled":false,"alwaysOn":false,"appCommandLine":"","managedPipelineMode":"Integrated","virtualApplications":[{"virtualPath":"/","physicalPath":"site\\wwwroot","preloadEnabled":false}],"loadBalancing":"LeastRequests","experiments":{"rampUpRules":[]},"autoHealEnabled":false,"vnetName":"","cors":{"allowedOrigins":["https://functions.azure.com","https://functions-staging.azure.com","https://functions-next.azure.com"]},"localMySqlEnabled":false}}';

	Invoke-ASRestMethod $url3 $data "PUT"
		
}

#Set Function apps standard configuration data end

#Function to deploy the artifacts to the Azure function in Azure environment
function Deploy-FunctionApp($resourceGroupName, $storageAccountName, $containerName, $funcartifact, $appURL , $blobURL, $functionAppName){
	Write-Host "Uploading ZIP package to Azure Storage..."
	$storageAccount=Get-AzureRmStorageAccount -ResourceGroupName  $resourceGroupName -AccountName $storageAccountName
	$ctx = $storageAccount.Context
	$dateTime = get-date -UFormat "%Y%m%d%H%M%S"
	$fileName=$functionAppName+$dateTime+'.zip'
	Set-AzureStorageBlobContent -File $funcartifact -Container $containerName -Blob $fileName -Context $ctx 

	Write-Host "Deploying Function App with package."
	$data = '{"properties":{"addOnPackages":[{"packageUri":"'+$blobURL+$fileName+'"}]}}';
	Write-Host $data
	Invoke-ASRestMethod $appURL $data "PUT"
	
	Start-Sleep 30
	Write-Host "Deleting deployment package from Azure Storage."
	Remove-AzureStorageBlob -Container $containerName -Blob $fileName -Context $ctx 
}


$blobURL="https://"+$storageAccount+".blob.core.windows.net/"+$containerName+"/"

$url3=$authBaseURL+$functionAppName1+"/extensions/MSDeploy"+$apiVersion
Write-Host $url3
#Call to deploy the Azure Cloud Function
Deploy-FunctionApp $resourceGroupName $storageAccount $containerName $funcartifact1 $url3 $blobURL $functionAppName1

$url3=$authBaseURL+$functionAppName2+"/extensions/MSDeploy"+$apiVersion
Write-Host $url3
#Call to deploy the Azure Monitor Function
Deploy-FunctionApp $resourceGroupName $storageAccount  $containerName  $funcartifact2   $url3 $blobURL $functionAppName2

#Completes the function app deployments
Write-Host "Deployment process completed."