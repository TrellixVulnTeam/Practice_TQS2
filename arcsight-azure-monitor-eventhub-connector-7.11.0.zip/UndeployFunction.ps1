#PowerShell
#Script to deploy azure function apps to the azure environment
#It prompts for the user credential who account will be used for deploying the azure function apps

#Read the properties file
$file_content = Get-Content ".\app.properties" -raw
$file_content = [Regex]::Escape($file_content)
$file_content = $file_content -replace "(\\r)?\\n", [Environment]::NewLine
$configuration = ConvertFrom-StringData($file_content)

$resourceGroupName=$configuration.'resourceGroupName'
$functionAppName1=$configuration.'functionAppName1'
$functionAppName2=$configuration.'functionAppName2'
$location=$configuration.'location'
$storageAccount=$configuration.'storageAccount'
$containerName=$configuration.'containerName'
$funcartifact1=$configuration.'funcartifact1'
$funcartifact2=$configuration.'funcartifact2'
$eventRetentionDays=$configuration.'eventRetentionDays'
$hubPartitionCount=$configuration.'hubPartitionCount'
$eventhubNamespaceName=$configuration.'eventhubNamespaceName'
$apiVersion="?api-version="+$configuration.'apiVersion';

$Azure = Get-AzureRmEnvironment 'AzureCloud'

#Connect to Azure resource manager account
Remove-AzureRmAccount  -EA SilentlyContinue
Add-AzureRmAccount

#Open the window with all the available subscriptions for selection
$Subscription = (Get-AzureRmSubscription | Out-GridView -Title "Selectt the auth profile" -PassThru)

#Retrieve the subscription id for later use
$subscriptionId =$Subscription.SubscriptionId;
$authBase="https://management.azure.com/subscriptions/"+$subscriptionId
Function Subscription {
	Get-AzureRmSubscription -SubscriptionId $subscriptionId | Select-AzureRmSubscription
}
$tentantID = $Subscription.TenantId;
$activityLogProfileUrl=$authBase+"/providers/microsoft.insights/logprofiles/default"+"?api-version="+$configuration.'activityLogAPIVersion';
$AdEventSubscriberName = $configuration.'adEventHubSubscriberName'
$adEventLogProfileUrl = "https://management.azure.com/providers/microsoft.aadiam/diagnosticSettings/"+$AdEventSubscriberName+"?api-version="+$configuration.'adAPIVersion';
$contentType = "application/json";
#Set the subscription for this script to operate
Set-AzureRMContext -Subscription $subscriptionId -NAME $Subscription.Name
Write-Host "Are you sure to uninstall the function apps?"

Write-Host "Note this will delete the ResourceGroup: "$resourceGroupName",  Storageaccount: "$storageAccount " Function app: "$functionAppName1", Function App:" $functionAppName2", EventhubNamespaceName: "$eventhubNamespaceName "and all eventhubs associated with the namesspace"

$answer = Read-Host "Yes or No"
while("yes","no","y","n" -notcontains $answer)
{
	$answer = Read-Host "Yes or No"
}

if("no","n" -contains $answer){
		exit;
}

Remove-AzureRmResourceGroup -Name $resourceGroupName -Verbose -Force

$appDetail=Get-AzureRmADApplication -DisplayName $configuration.'adapplicationName' | Select-Object -first 1

Remove-AzureRmADApplication -ObjectId $appDetail.ObjectId.Guid -Verbose -Force

#Function which retrieve the auth token to access the Azure management rest API
Function RESTAPI-Auth {
	# Load ADAL Azure AD Authentication Library Assemblies
	Subscription
	$adTenant = $Subscription.TenantId
	# Client ID for Azure PowerShell
	$clientId = "1950a258-227b-4e31-a9cf-717495945fc2"
	# Set redirect URI for Azure PowerShell
	$redirectUri = "urn:ietf:wg:oauth:2.0:oob"
	# Set Resource URI to Azure Service Management API | @marckean
	#$resourceAppIdURIASM = "https://management.core.windows.net/"
	$resourceAppIdURIARM = "https://management.azure.com/"
	 
	# Authenticate and Acquire Token
	 
	# Set Authority to Azure AD Tenant
	$authority = "https://login.windows.net/$adTenant"
	# Create Authentication Context tied to Azure AD Tenant
	$authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authority
	# Acquire token
	#$global:authResultASM = $authContext.AcquireToken($resourceAppIdURIASM, $clientId, $redirectUri, "Auto")
	$global:authResultARM = $authContext.AcquireToken($resourceAppIdURIARM, $clientId, $redirectUri, "Auto")
}

# Call the functions above
RESTAPI-Auth # To Logon to Rest and get an an auth key
$authHeader = $global:authResultARM.CreateAuthorizationHeader();

# Set HTTP request headers to include Authorization header
$requestHeader = @{
	"Accept"="application/json"
	"Authorization" = $authHeader
}
#Function that invokes the Azure RM Invoke-WebRequest based on the parameters & returns the result to the caller
function Invoke-ASWebRequest($functionURL, $method){
	$Result =Invoke-WebRequest -Method $method -Uri $functionURL -ContentType $contentType -Headers $requestHeader;
	return $Result
}

$Result = Invoke-ASWebRequest $adEventLogProfileUrl "DELETE"
$AdEventHubName = $configuration.'adEventHubName'
if($Result.StatusCode -eq 200){
		Write-Host "Successfully destreamed the Azure Active Directory Audit and SignIn events to "$AdEventHubName " event hub."
	}
	else{
		Write-Host "Unable to destreamed Azure Active Directory events to "$AdEventHubName ". Please proceed with manual configuration.";
}

$Result = Invoke-ASWebRequest $activityLogProfileUrl "DELETE"
if($Result.StatusCode -eq 200){
		Write-Host "Successfully destreamed the Azure Active Directory Audit and SignIn events to "$configuration.'activityEventHubName' " event hub."
	}
	else{
		Write-Host "Unable to destreamed Azure Active Directory events to "$configuration.'activityEventHubName' ". Please proceed with manual configuration.";
}

Write-Host "Uninstall of function app completed."