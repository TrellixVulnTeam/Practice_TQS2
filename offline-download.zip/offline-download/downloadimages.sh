#!/bin/bash
usage() {
    echo "Usage: ./downloadimages.sh [-y|--yes] [-u|--user <username>] [-p|--pass <password>] [-r|--registry <registry-url>] [-c|--content-trust <on/off>] [-t|--retry <retry times>] "
    echo "       -y|--yes            Answer yes for any confirmations."
    echo "       -d|--dir            Suite images tar directory path (The default value is /var/opt/kubernetes/offline)."
    echo "       -u|--user           Registry host account username."
    echo "       -p|--pass           Registry host account password. Wrap the 'password' in single quotes."
    echo "       -P|--Pass-cmd       Command to get and refresh short term password.Wrap the password with single quotes"
    echo "       -r|--registry       The host name of the registry that you want to pull suite images from."
    echo "       -c|--content-trust  Use \"on/off\" to enable/disable content trust."
    echo "       -t|--retry          The retry times when the image download fails."
    echo "       -h|--help           Show help."
    exit 1
}

while [[ ! -z $1 ]] ; do
    case "$1" in
        -y|--yes) CONFIRM=true; shift ;;
        -u|--user)
        case "$2" in
            -*) echo "-u|--user parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-u|--user parameter requires a value. " ; exit 1 ; fi ; USER_NAME=$2 ; shift 2 ;;
        esac ;;
        -p|--pass)
        case "$2" in
            -*) echo "-p|--pass parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-p|--pass parameter requires a value. " ; exit 1 ; fi ; PASSWORD=$2 ; shift 2 ;;
        esac ;;
        -P|--pass-cmd)
        case "$2" in
            -*) echo "-pc|--pass-cmd parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-pc|--pass-cmd parameter requires a value. " ; exit 1 ; fi ; PASSWORD_CMD=$2 ; shift 2 ;;
        esac ;;
        -r|--registry)
        case "$2" in
            -*) echo "-r|--registry parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-r|--registry parameter requires a value. " ; exit 1 ; fi ; REGISTRY_BASE=$2 ;shift 2 ;;
        esac ;;
        -c|--content-trust)
        case "$2" in
            -*)  echo "-c|--content-trust parameter requires a value. " ; exit 1 ;;
            on)  CONTENT_TRUST="true" ; shift 2 ;;
            off) CONTENT_TRUST="false" ; shift 2 ;;
            *)   echo "invalid value for -c|--content-trust"; exit 1 ;;
        esac ;;
        -n|--notary-server)
        case "$2" in
            -*) echo "-n|--notary-server parameter requires a value. " ; exit 1 ;;
            *) if [[ -z $2 ]] ; then echo "-n|--notary-server parameter requires a value. " ; exit 1 ; fi ; NOTARY_SERVER=$2 ; shift 2 ;;
        esac ;;
        -t|--retry)
        case "$2" in
            -*) echo "-t|--retry parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-t|--retry parameter requires a value. " ; exit 1 ; fi ; MAX_RETRY=$2 ; shift 2 ;;
        esac ;;
        -d|--dir)
        case "$2" in
            -*) echo "-d|--dir parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-d|--dir parameter requires a value. " ; exit 1 ; fi ; IMAGE_BASE_DIR=$2 ; shift 2 ;;
        esac ;;
        *|-*|-h|--help|/?|help) usage ;;
    esac
done

readonly NEW_IFS=$'\n'
readonly DEFAULT_IMAGE_BASE_DIR="/var/opt/kubernetes/offline/"

BASICAUTH=""
AUTH_TYPE=""
AUTH_BASE=""
AUTH_SERVICE=""
NOTARY_AUTH=""
PID_ARRAY=()
CURL_SECURE_OPT="-k "
CURL_NOPROXY_OPT=""
SUCCESS_FILE=""
FAIL_FILE=""
LAYER_FAIL_FILE=""
LOCK_FILE=""
LOG_FILE=""
LOG_FILE_NAME="downloadimages-`date "+%Y%m%d%H%M%S"`.log"

CURRENT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
IMAGE_SET_FILE="${CURRENT_DIR}/image-set.json"

MAX_RETRY=${MAX_RETRY:-"5"}
USER_NAME=${USER_NAME:-""}
PASSWORD=${PASSWORD:-""}
PASSWORD_CMD=${PASSWORD_CMD:-""}
CONFIRM=${CONFIRM:-"false"}
CONTENT_TRUST=${CONTENT_TRUST:-"false"}
REGISTRY_BASE=${REGISTRY_BASE:-"https://registry-1.docker.io"}
IMAGE_BASE_DIR=${IMAGE_BASE_DIR:-"${DEFAULT_IMAGE_BASE_DIR}"}
NOTARY_SERVER=${NOTARY_SERVER:-"https://notary.docker.io"}


write_log() {
    local level=$1
    local msg=$2
    local exitCode=1
    local timestamp=$(date --rfc-3339='ns')
    timestamp=${timestamp:0:10}"T"${timestamp:11}
    if [[ ! -z $3 ]] ; then
        exitCode=$3
    fi
    case $level in
        debug) #debug level is dedicated for write to logfile,not to stdout
            echo -e "${timestamp} DEBUG $msg  " >> $LOG_FILE ;;
        debugln) #in case when write_log "begin" is used, the next line is often concated, use this "debugln" to avoid
            echo -e "\n${timestamp} DEBUG $msg  " >> $LOG_FILE ;;
        info|warn|error)
            echo -e "$msg" && echo -e "${timestamp} `echo $level|tr [:lower:] [:upper:]` $msg  " >> $LOG_FILE ;;
        begin)
            echo -e "$msg\c"
            echo -e "${timestamp} INFO $msg \c" >> $LOG_FILE ;;
        end)
            echo "$msg"
            echo "$msg" >> $LOG_FILE ;;
        fatal)
            echo -e "$msg. \n Please refer to $LOG_FILE for more detail. "
            echo -e "${timestamp} FATAL $msg  " >> $LOG_FILE
            exit ${exitCode}
            ;;
        *)
            echo -e "$msg"
            echo -e "${timestamp} INFO $msg  " >> $LOG_FILE ;;
    esac
}

padSlash(){
    local path=$1
    if [ -n "$path" -a "${path:$((-1))}" != "/" ] ; then
        path="$path/"
    fi
    echo $path
}
releaseLockFile(){
    LOCK_FILE="${IMAGE_BASE_DIR}.download-lock"     #refresh file path as the base dir may renamed
    if [[ -f "$LOCK_FILE" ]] && [[ "$(cat $LOCK_FILE)" = "$$" ]] ; then 
        rm -f $LOCK_FILE
    fi
}
makeSingleton(){
    if [[ -f "$LOCK_FILE" ]] ; then
        write_log "error" "Error: one instance is already running and only one instance is allowed at a time. "
        write_log "error" "Check to see if another instance is running."
        write_log "fatal" "If the instance stops running, delete $LOCK_FILE file."
    else
        echo "$$" > $LOCK_FILE
    fi
}
getConcurrencyFactor(){
    local cpuNum=$(cat /proc/cpuinfo 2>/dev/null |grep "processor"|sort -u|wc -l)
    if [[ -z "${cpuNum}" ]] || [[ ${cpuNum} -eq 0 ]] ; then
        cpuNum=4
    fi
    #echo $((cpuNum/2))
    echo $cpuNum
}
shellSemInit(){
    local value=$1
    mkfifo mulfifo
    exec 1000<>mulfifo
    rm -rf mulfifo
    for ((n=1;n<=${value};n++))
    do
            echo >&1000
    done
}
shellSemWait(){
    read -u1000
}
shellSemPost(){
    echo >&1000
}
shellSemDestroy(){
    exec 1000>&-
    exec 1000<&-
}
killTasks(){
    for pid in ${PID_ARRAY[@]} ; do
        kill -9 $pid 2>/dev/null
    done
}

taskClean(){
    killTasks
    releaseLockFile
    shellSemDestroy
    stty $old
    SUCCESS_FILE="${IMAGE_BASE_DIR}success.log"     #refresh file path as the base dir may renamed
    FAIL_FILE="${IMAGE_BASE_DIR}fail.log"           #refresh file path as the base dir may renamed
    LAYER_FAIL_FILE="${IMAGE_BASE_DIR}layer_fail.log" #refresh
    rm -f ${IMAGE_BASE_DIR}/*.tmp
    rm -f ${SUCCESS_FILE}
    rm -f ${FAIL_FILE}
    rm -f ${LAYER_FAIL_FILE}
}
checkCommand(){
    local cmd=$1
    res=$( which $cmd > /dev/null 2>& 1; echo $? )
    if [ $res -ne 0 ] ; then
        write_log "fatal" "$cmd not found in PATH($PATH)"
    fi
}
checkTools(){
    checkCommand curl
    checkCommand jq
    if [ "$CONTENT_TRUST" == "true" ] ; then
        checkCommand notary
    fi
}
checkFile(){    #check if $file exist under $dir
    local file_path
    if [ $# -eq 1 ] ;then
        file_path=$1
    else
        local dir=$1
        local file=$2

        dir=$(padSlash $dir)
        file_path=$dir$file
    fi

    if [ ! -f $file_path ] ; then
        write_log "fatal" "$file_path not found"
    fi
}
checkFiles(){
    checkFile "$IMAGE_SET_FILE"
}
readLoginInfo() {
    local retry_time=$1;shift
    local user_tmp=""
    local need_input_password="false"
    if [ -z "$USER_NAME" ];then
        read -p "Username:" USER_NAME
        need_input_password="true"
    else
        if [[ $retry_time -gt 0 ]];then #user have provide username and password
            read -p "Username(${USER_NAME})" user_tmp
            if [ -n "$user_tmp" ];then  #use the name in ()
                USER_NAME=$user_tmp
            fi
            need_input_password="true"
        fi
    fi

    if [ -z "$PASSWORD" ] || [ "$need_input_password" == "true" ];then
        stty -echo
        read -p "Password:" PASSWORD
        stty $old
        echo ""
    fi
}
refreshBasicAuth() {
    if [ -n "$PASSWORD_CMD" ];then
        PASSWORD=$(eval ${PASSWORD_CMD})
        BASICAUTH="$USER_NAME:$PASSWORD"
    fi
}
contactRegistryByCurl(){
    local result=125
    local scheme="" token="" status_code="" curl_cmd="" http_resp=""

    #step 1. intentify the protocal scheme
    for scheme in "https://" "http://" ; do
        http_resp=$(curl --connect-timeout 20 -s -w %{http_code} ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/)
        status_code=${http_resp:0-3}
        case "$status_code" in 
            200)
                if [ $(echo -e "$http_resp" | grep "blocked" | wc -l) -ne 0 ];then #special handling for docker hub
                    continue
                else
                    AUTH_TYPE=""; AUTH_BASE=""; AUTH_SERVICE=""; result=0; break
                fi
                ;;
            401) 
                AUTH_BASE=$(curl    -s -I ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/ | grep "realm" | cut -d = -f2 | cut -d , -f1 | tr -d ["\" \r"])
                AUTH_TYPE=$(curl    -s -I ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/ | grep "realm" | cut -d = -f1 | cut -d ' ' -f2)
                AUTH_SERVICE=$(curl -s -I ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/ | grep "realm" | cut -d , -f2 | cut -d = -f2| tr -d ["\" \r"])  
                AUTH_SERVICE=${AUTH_SERVICE// /%20} #escape space
                result=1
                break
                ;;
            *) ;;
        esac
    done
    REGISTRY_BASE=${scheme}${REGISTRY_BASE}

    #step 2. check if the credential is correct
    if [[ $result -eq 1 ]];then
        for((i=0;i<$MAX_RETRY;i++));do
            if [[ -z "$USER_NAME" ]] && [[ -z "$PASSWORD" ]];then
                BASICAUTH=""
            else
                BASICAUTH="$USER_NAME:$PASSWORD"
            fi  
            case "$AUTH_TYPE" in
            Basic) #if basic auth, and not credential needed, it is same as anonymous auth
                token=$(echo -n "$BASICAUTH" | base64 -w0);;
            Bearer)
                if [ -z "$BEARER_TOKEN" ];then
                    local auth_opt="" 
                    if [ -n "$BASICAUTH" ];then
                        auth_opt="-u $BASICAUTH"
                    fi
                    curl_cmd="curl -s ${CURL_SECURE_OPT} $auth_opt \"${AUTH_BASE}?service=${AUTH_SERVICE}\""
                    token=$(eval $curl_cmd | jq --raw-output '.token?')
                    TOKEN_TYPE="token"
                    if [ "$token" == "null" ];then
                        token=$(eval $curl_cmd | jq --raw-output '.access_token?')
                        TOKEN_TYPE="access_token"
                    fi
                else
                    token=$BEARER_TOKEN
                fi
                ;;
            *);;
            esac
            status_code=$(curl -s -w %{http_code} ${CURL_SECURE_OPT} -H "Authorization: $AUTH_TYPE $token" "$REGISTRY_BASE/v2/")
            status_code=${status_code:0-3}
            if [ "$status_code" == "200" ];then
                result=0
                break
            else
                write_log "error" "Failed to login to $REGISTRY_BASE, please make sure your user name, password and network/proxy configuration are correct."
                write_log "info" "Retrying contacting $REGISTRY_BASE ..."
                readLoginInfo $i
            fi
        done
    fi
    return $result
}

contactRegistry(){
    local reg_host
    if [[ "$REGISTRY_BASE" =~ "://" ]];then  #if user provide registry with http/https scheme, remove it
        REGISTRY_BASE=${REGISTRY_BASE#*://}
    fi
    reg_host=$REGISTRY_BASE
    write_log "info" "Contacting Registry: $reg_host ..."

    contactRegistryByCurl

    if [[ $? -eq 0 ]];then
        write_log "info" "Contacting Registry: $reg_host OK"
    else
        write_log "info" "Contacting Registry: $reg_host FAILED"
        write_log "fatal" "Failed to login to $reg_host, please make sure your user name, password and network/proxy configuration are correct."
    fi
    write_log "debug" "IMAGE_BASE_DIR: $IMAGE_BASE_DIR, REGISTRY_BASE: $REGISTRY_BASE, ORG_NAME:$ORG_NAME, USING_EXT_REGISTRY:$USING_EXT_REGISTRY, AUTH_TYPE: $AUTH_TYPE,  AUTH_BASE: $AUTH_BASE,  AUTH_SERVICE: $AUTH_SERVICE"    
}

init(){
    IMAGE_BASE_DIR=$(padSlash $IMAGE_BASE_DIR)
    CURRENT_DIR=$(padSlash $CURRENT_DIR)
    local image_set_hash=$(sha256sum $IMAGE_SET_FILE | cut -d ' ' -f 1)
    if [ "$IMAGE_BASE_DIR" == "$DEFAULT_IMAGE_BASE_DIR" ];then
        IMAGE_BASE_DIR="${IMAGE_BASE_DIR}images_${image_set_hash}/" #set base dir as :/<Base_dir>/images_<hash>/ if use default base dir
    fi
    SUCCESS_FILE="${IMAGE_BASE_DIR}success.log"
    FAIL_FILE="${IMAGE_BASE_DIR}fail.log"
    LAYER_FAIL_FILE="${IMAGE_BASE_DIR}layer_fail.log"
    LOCK_FILE="${IMAGE_BASE_DIR}.download-lock"
    LOG_FILE="${IMAGE_BASE_DIR}${LOG_FILE_NAME}"

    if [[ ! -d ${IMAGE_BASE_DIR} ]];then
        mkdir -p ${IMAGE_BASE_DIR}
    fi

    checkTools
    checkFiles
    makeSingleton
    refreshBasicAuth
}

printProcessInfoBegin(){
    local index=$1;shift
    local total=$1;shift
    local reg_host=$(padSlash $1);shift
    local org_name=$(padSlash $1);shift
    local image_name=$1;shift
    local image_tag=$1;shift

    rm -rf $LAYER_FAIL_FILE
    if [[ "$reg_host" =~ "://" ]];then
        reg_host=${reg_host#*://}
    fi
    write_log "begin" "Downloading image [${index}/${total}] ${reg_host}${org_name}$image_name:$image_tag ... "
}
printProcessInfoEnd(){
    local result=$1;shift
    write_log "end" "$result"
}
getOneImageDigest(){
    local im=$1

    local repo=${im%:*}
    local tag=${im#*:}
    local prefix=${NOTARY_SERVER#*notary.}

    local success="false"
    for((i=0;i<$MAX_RETRY;i++))
    do
        write_log "debug" "notary lookup -s $NOTARY_SERVER ${prefix}/${repo} $tag"
        local resp=$(notary lookup -s $NOTARY_SERVER ${prefix}/${repo} $tag)
        write_log "debug" "notary resp:$resp"
        if [[ "$resp" =~ "sha256" ]];then
            write_log "debug" "notary lookup success"
            success="true"
            break
        fi
        write_log "debug" "notary lookup -s $NOTARY_SERVER ${prefix}/${repo} $tag failed, retry in 2 second later"
        sleep 2
    done

    if [ "$success" == "true" ] ; then
        local digest=$(echo $resp | cut -d ' ' -f2)
        echo $digest 
    else
        echo "failed"
    fi
}

getAuthToken(){
    local image_name=$1;shift
    local org_name=$1;shift
    local curl_cmd="" token=""
    if [ -z "$AUTH_TYPE" ];then
        token=""
    elif [ -n "$BEARER_TOKEN" ];then
        token=$BEARER_TOKEN
    else
        refreshBasicAuth
        if [ "$AUTH_TYPE" == "Basic" ]; then
            token=$(echo -n "$BASICAUTH" | base64 -w0)
        else
            local basic_auth=""
            if [ -n "$BASICAUTH" ];then
                basic_auth="-u $BASICAUTH"
            fi
            local repo
            if [ -z "$org_name" ];then
                repo=${image_name}
            else
                repo=${org_name}/${image_name}
            fi
            local query_string="?service=${AUTH_SERVICE}&scope=repository:${repo}:pull"
            write_log "debug" "curl -s ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -u *** ${AUTH_BASE}${query_string}"
            token=$(curl -s ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${basic_auth} ${AUTH_BASE}${query_string} 2>>$LOG_FILE | jq -r ".${TOKEN_TYPE}?")
            #write_log "debug" "get token=$token"
        fi
    fi 
    echo  $token
}
# https://github.com/moby/moby/issues/33700
fetchBlob() {
    local image="$1"; shift
    local digest="$1"; shift
    local targetFile="$1"; shift

    local org_name img_name
    if [[ "$image" =~ "/" ]];then
        org_name=${image%%/*}
        img_name=${image#*/}
    else
        org_name="library"
        img_name=${image}
    fi

    write_log "debug" "Begin to download layer[image=$image,digest=$digest]"

    local result=1
    for((i=0;i<$MAX_RETRY;i++))
    do
        local url="$REGISTRY_BASE/v2/$image/blobs/$digest"
        local token=$(getAuthToken "$img_name" "$org_name")
        
        write_log "debug" "Download layer with command:curl -S -s ${CURL_SECURE_OPT} -H \"Authorization: $AUTH_TYPE ***\" $url -o $targetFile"
        local curlHeaders="$(curl -S -s ${CURL_SECURE_OPT} -H "Authorization: $AUTH_TYPE $token" "$url" -o "$targetFile" -D- 2>>$LOG_FILE)"
        curlHeaders="$(echo "$curlHeaders" | tr -d '\r')"; 
        if grep -qE "^HTTP/[0-9].[0-9] 3" <<<"$curlHeaders"; then
            rm -f "$targetFile"

            local blobRedirect="$(echo "$curlHeaders" | awk -F ': ' 'tolower($1) == "location" { print $2; exit }')"
            write_log "debug" "Download layer[image=$image,digest=$digest]:redirect to url:$blobRedirect"
            if [ -n "$blobRedirect" ]; then
                write_log "debug" "Download layer with command:curl -fSL -s ${CURL_SECURE_OPT} $blobRedirect -o $targetFile"
                curl -fSL -s ${CURL_SECURE_OPT} "$blobRedirect" -o "$targetFile" 2>>$LOG_FILE
            fi
        fi

        if [[ -f "$targetFile" ]];then #make sure the downloaded layer digest is correct
            local checksum=$(sha256sum $targetFile | cut -d ' ' -f 1)
            if [[ "$digest" =~ "$checksum" ]];then
                result=0
                break
            else
                write_log "debug" "Layer digest check for [image=$image,digest=$digest]: failed"
                rm -f $targetFile
            fi
        fi

        write_log "debug" "Download layer[image=$image,digest=$digest]:failed, retry in 2 seconds"
        sleep 2
    done

    if [[ $result -ne 0 ]];then
        write_log "debug" "Download layer[image=$image,digest=$digest]:failed"
        echo $digest >> $LAYER_FAIL_FILE
    fi

    write_log "debug" "Download layer[image=$image,digest=$digest] OK"
    shellSemPost
    return $result
}

fetchManifest(){
    local image=$1
    local digest=$2

    local org_name img_name
    if [[ "$image" =~ "/" ]];then
        org_name=${image%%/*}
        img_name=${image#*/}
    else
        org_name="library"
        img_name=${image}
    fi

    write_log "debugln" "Begin to download manifest[image=$image,digest=$digest]"

    for((i=0;i<$MAX_RETRY;i++)); do
        local url="$REGISTRY_BASE/v2/$image/manifests/$digest"
        local token=$(getAuthToken "$img_name" "$org_name")
        
        write_log "debug" "Download manifest with command: curl -fsSL ${CURL_SECURE_OPT} -H \"Authorization: $AUTH_TYPE ***\" -H \"Accept: application/vnd.docker.distribution.manifest.v2+json\" -H \"Accept: application/vnd.docker.distribution.manifest.list.v2+json\" -H \"Accept: application/vnd.docker.distribution.manifest.v1+json\" $url"
        local manifestJson="$(
            curl -fsSL ${CURL_SECURE_OPT} \
                -H "Authorization: $AUTH_TYPE $token" \
                -H 'Accept: application/vnd.docker.distribution.manifest.v2+json' \
                -H 'Accept: application/vnd.docker.distribution.manifest.list.v2+json' \
                -H 'Accept: application/vnd.docker.distribution.manifest.v1+json' \
                "$url"  2>>$LOG_FILE
        )"

        if [ -n "${manifestJson}" ] ; then
            break
        fi
        write_log "debug" "Downloading manifest[image=$image,digest=$digest]:failed,retry in 2 secondes"
        sleep 2
    done

    if [ "${manifestJson:0:1}" != '{' ]; then
        write_log "debug" "Download manifest[image=$image,digest=$digest]:failed"
        manifestJson=""
    else
        write_log "debug" "Download manifest[image=$image,digest=$digest]:OK"
    fi
    echo $manifestJson
}
# handle 'application/vnd.docker.distribution.manifest.v2+json' manifest
handleSingleManifestV2() {
    local manifestJson="$1"; shift
    local image="$1";shift
    local factor=$(getConcurrencyFactor)
    shellSemInit $factor
    write_log "debug" "Begin to handle manifest[image=$image,manifestJson=$manifestJson]"

    local configDigest="$(echo "$manifestJson" | jq --raw-output '.config.digest')"
    local imageId="${configDigest#*:}" # strip off "sha256:"

    shellSemWait
    local configFile="$imageId.json"
    if [[ $(fetchBlob "$image" "$configDigest" "${IMAGE_BASE_DIR}${configFile}"; echo $?) -ne 0 ]];then
        return 1
    fi

    local layersFs="$(echo "$manifestJson" | jq --raw-output --compact-output '.layers[]')"
    local IFS="$NEW_IFS"
    local layers=( $layersFs )
    unset IFS

    
    local layerId=
    local layerFiles=()

    for i in "${!layers[@]}"; do
        local layerMeta="${layers[$i]}"

        local layerMediaType="$(echo "$layerMeta" | jq --raw-output '.mediaType')"
        local layerDigest="$(echo "$layerMeta" | jq --raw-output '.digest')"
        local layerSize="$(echo "$layerMeta" | jq --raw-output '.size')"
        layerId=${layerDigest#*:}
        if [ "$layerMediaType" == "application/vnd.docker.image.rootfs.diff.tar.gzip" ];then
            local layerTar="${layerId}.tar.gz"
            layerFiles=( "${layerFiles[@]}" "$layerTar" )
            if [ -f "$IMAGE_BASE_DIR/$layerTar" ]; then
                local size=$(stat -c "%s" $IMAGE_BASE_DIR/$layerTar)
                if [[ $size -eq $layerSize ]];then
                    write_log "debug" "Skipping existing layer: ${layerId:0:12}"
                    continue
                else
                    write_log "debug" "Found currupted layer:$layerTar,remove it and re-download"
                    rm -rf $IMAGE_BASE_DIR/$layerTar
                fi
            fi
            shellSemWait
            fetchBlob "$image" "$layerDigest" "${IMAGE_BASE_DIR}${layerTar}" &
        else
            write_log "error" "Handling manifest[image=$image,layer:$layerMediaType]:unknown layer mediaType=$layerMediaType"
            echo $layerDigest >> $LAYER_FAIL_FILE
            break
        fi
    done

    wait
    local fail_cnt=$(cat ${LAYER_FAIL_FILE}   2>/dev/null | wc -l)
    if [[ $file_cnt -ne 0 ]]; then
        write_log "error" "Handling manifest[image=$image]: failed to download some layers"
        return 1
    fi

    local manifestJsonEntry="$(
        echo '{}' | jq --raw-output '. + {
            Config: "'"$configFile"'",
            RepoTags: ["'"${image#library\/}:$tag"'"],
            Layers: '"$(echo '[]' | jq --raw-output ".$(for layerFile in "${layerFiles[@]}"; do echo " + [ \"$layerFile\" ]"; done)")"'
        }'
    )"
    local imageFile="${image//\//_}"
    echo $manifestJsonEntry > ${IMAGE_BASE_DIR}/${imageFile}_${tag}.tmp
    write_log "debug" "Handle manifest[image=$image]: download all layers OK"
    return 0
}
pullOneImage(){
    local organization=$(padSlash $1);shift
    local image_tag=${organization}$1;shift
    local index=$1;shift
    local total=$1;shift
    write_log "debug" "Begin to pull image[org_name=$organization,image=$image_tag,$index/$total]"

    local image="${image_tag%%[:@]*}"
    local name="${image##*/}"
    local tag_digest="${image_tag#*:}"
    local digest="${tag_digest##*@}"
    local tag="${tag_digest%%@*}"

    printProcessInfoBegin "$index" "${total}" "" "$organization" "$name" "$tag"
    local index

    if [ "$CONTENT_TRUST" == "true" ] ; then
        local auth_code=$(echo "${USER_NAME}:${PASSWORD}" | base64)
        export NOTARY_AUTH=$auth_code
        digest=$(getOneImageDigest "$image_tag")
        unset NOTARY_AUTH
        if [ "$digest" == "failed" ] ; then
            echo "$image_tag" >> $FAIL_FILE
            printProcessInfoEnd "CONTENT TRUST FAILED"
            return
        fi
    fi

    # add prefix library if passed official image
    if [[ "$image" != *"/"* ]]; then
        image="library/$image"
    fi

    local imageFile="${image//\//_}" # "/" can't be in filenames :)
    local manifestJson=$(fetchManifest $image $digest)
    if [ -z "$manifestJson" ] ; then
        echo "$image_tag" >> $FAIL_FILE
        printProcessInfoEnd "NOT FOUND"
        return
    fi
    echo "$manifestJson" > ${IMAGE_BASE_DIR}${imageFile}_${tag}.manifest
    local imageIdentifier="$image:$tag@$digest"
    local schemaVersion="$(echo "$manifestJson" | jq --raw-output '.schemaVersion')"
    local mediaType="$(echo "$manifestJson" | jq --raw-output '.mediaType')"

    if [ "$schemaVersion" != "2" ];then
        write_log "error" "Pull image[org_name=$organization,image=$image_tag,$index/$total]:unsupport manifest schemaVersion: '$schemaVersion'"
    else
        if [ "$mediaType" != "application/vnd.docker.distribution.manifest.v2+json" ];then
            write_log "error" "Pull image[org_name=$organization,image=$image_tag,$index/$total]:unsupport mediaType: '$mediaType'"
        else
            handleSingleManifestV2 "$manifestJson" "$image"
            if [ $? -ne 0 ];then
                echo "$image_tag" >> $FAIL_FILE
                printProcessInfoEnd  "FAILED"
             else
                printProcessInfoEnd  "OK"
            fi
        fi
    fi
}
gatherManifestInfo(){ #in case when there are too many images jq will complaint of too many argument list,so not use jq here
    local index=1
    local file_cnt=$(ls $IMAGE_BASE_DIR/ | grep ".tmp" | wc -l)

    rm -f "${IMAGE_BASE_DIR}/manifest.json"
    echo  "[" >> ${IMAGE_BASE_DIR}/manifest.json
    for manif in `ls $IMAGE_BASE_DIR/ | grep ".tmp"`
    do
        cat ${IMAGE_BASE_DIR}/$manif 2>/dev/null >>${IMAGE_BASE_DIR}/manifest.json
        if [[ $index -lt $file_cnt ]];then
            echo "," >>${IMAGE_BASE_DIR}/manifest.json
        fi
        ((index+=1))
    done
    echo  "]" >> ${IMAGE_BASE_DIR}/manifest.json
    echo $?    ##when disk out of space, write will fail, and the return code can be used as an indicator for such error
}
diskConfirmation() {
    if [ "$CONFIRM" == "false" ]; then
        local answer
        write_log "info" "! Warning: Please check suite sizing documentation and make sure you have enough disk space for downloading suite images."
        read -p "Continue?[Y/N]?" answer
        case $answer in
            Y | y) ;;
            *) write_log "fatal" "User cancel the download,answer=$answer" ;;
        esac
    fi
}

printProcessResult(){ #write_log is not usable here, as the $LOG_FILE may changed due to rename
    local suite_name=$1;shift
    local suite_version=$1;shift    
    local result=$1;shift
    local fail_num=0
    local fail_array
    FAIL_FILE="${IMAGE_BASE_DIR}fail.log"   #refresh these file path,as the base dir may be renamed
    LOG_FILE="${IMAGE_BASE_DIR}${LOG_FILE_NAME}"    #refresh
    if [ -f $FAIL_FILE ]; then
        fail_array=($(cat $FAIL_FILE 2>>$LOG_FILE | xargs))
        fail_num=${#fail_array[@]}
    fi
    if [[ $fail_num -eq 0 ]] && [[ $result -eq 0 ]]; then
        echo "Download-process successfully completed." | tee -a $LOG_FILE
        echo "Successfully downloaded the ${suite_name} suite version: ${suite_version} to $IMAGE_BASE_DIR. " | tee -a $LOG_FILE
    else
        for fail_item in ${fail_array[@]}; do
            echo "Failed to download $fail_item" | tee -a $LOG_FILE
        done
        echo "Download-process completed with errors." | tee -a $LOG_FILE
        echo "Downloaded the ${suite_name} suite version: ${suite_version} with errors." | tee -a $LOG_FILE
    fi
    write_log "info" "Please refer to $LOG_FILE for more detail"
}

pullSuiteImages() {
    local suite_name=$(cat $IMAGE_SET_FILE 2>>$LOG_FILE | jq -r '.suite')
    local suite_version=$(cat $IMAGE_SET_FILE 2>>$LOG_FILE | jq -r '.version')
    local organization=$(cat $IMAGE_SET_FILE 2>>$LOG_FILE | jq -r '.org_name')
    write_log "info" "Starting the download of the ${suite_name} suite, version ${suite_version} ..."
    diskConfirmation

    local images=($(cat $IMAGE_SET_FILE 2>>$LOG_FILE | jq -r '.images|.[]|.image'|xargs))
    local begin_time=$(date +%s)
    local total=${#images[@]}
    local index=1
    for im in ${images[@]}
    do
        pullOneImage "${organization}" "$im" "$index" "$total"
        index=$((index+1))
    done
    local result
    result=$(gatherManifestInfo)
    local end_time=$(date +%s)
    local cost_time=$(( ${end_time} - ${begin_time} ))
    write_log "info" "Download completed in ${cost_time} seconds."

    if [[ "$IMAGE_BASE_DIR" =~ "$DEFAULT_IMAGE_BASE_DIR" ]];then #when successfully finished, change images_<hash> to images_<timestamp>
        local fail_array fail_num
        if [ -f $FAIL_FILE ]; then
            fail_array=($(cat $FAIL_FILE 2>>$LOG_FILE | xargs))
            fail_num=${#fail_array[@]}
        fi
        if [[ $fail_num -eq 0 ]];then
            local time_stamp=$(date "+%Y%m%d%H%M%S")
            mv ${IMAGE_BASE_DIR} ${DEFAULT_IMAGE_BASE_DIR}images_${time_stamp}
            IMAGE_BASE_DIR=$(padSlash "${DEFAULT_IMAGE_BASE_DIR}images_${time_stamp}")
        fi
    fi
    printProcessResult "$suite_name" "$suite_version" "$result"
}


#########  MAIN  #########
trap 'taskClean; exit' 1 2 3 8 9 14 15 EXIT
old=$(stty -g)
export PATH=$PATH:$CURRENT_DIR:$CURRENT_DIR/../bin
init
contactRegistry
pullSuiteImages
