#!/bin/bash
if [ -f "/etc/profile" ]; then
    source /etc/profile
fi

if [ -f "${K8S_HOME}/bin/env.sh" ]; then
    source ${K8S_HOME}/bin/env.sh
    TMP_DIR="${K8S_HOME}/log/scripts/uploadimages"
fi
usage() {
    echo "Usage: ./uploadimages.sh [-y|--yes] [-u|--user <username>] [-p|--pass <password>] [-r|--registry <registry-url>] [-d|--dir <path>] [-t|--retry <retry times>] [-c|--concurrency <concurrency>]"
    echo "       -d|--dir          Path to downloaded suite images."
    echo "       -t|--retry        Number of retries if the image push fails." 
    echo "       -y|--yes          Answer yes for any confirmations."
    echo "       -r|--registry     The registry URL of the suite image repository."
    echo "       -u|--user         Username of registry host account."
    echo "       -p|--pass         Password of registry host account. Wrap the password with single quotes. For example, 'password'."
    echo "       -b|--bearer-token Authentication token for the registry whose authentication type is bearer (invalid when \"-l \" option is false )."
    echo "       -P|--Pass-cmd     Command to get and refresh short term password.Wrap the password with single quotes"
    echo "       -l|--bylayer      Set \"true/false\" to indicate if the images are in layer form(default is true)."
    echo "       -c|--concurrency  Set the working processes that run over the same time period(default is 1,maximum is half of the CPU cores)."
    echo "       -w|--overwrite    Set \"true/false\" to indicate if overwrite the existing images on the registry (default is false)."
    echo "       -o|--organization Organization name of the registry the images will be uploaded to."
    echo "       -h|--help         Show help."
    exit 1
}

while [[ ! -z $1 ]] ; do
    case "$1" in
        -d|--dir)
        case "$2" in
            -*) echo "-d|--dir parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-d|--dir parameter requires a value. " ; exit 1 ; fi ; IMAGE_BASE_DIR=$2 ; shift 2 ;;
        esac ;;
        -r|--registry)
        case "$2" in
            -*) echo "-r|--registry parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-r|--registry parameter requires a value. " ; exit 1 ; fi ; REGISTRY_BASE=$2 ; USER_PROVIDE_REGISTRY="true";shift 2 ;;
        esac ;;
        -o|--organization)  #for inner use
        case "$2" in
            -*) echo "-o|--organization parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-o|--organization parameter requires a value. " ; exit 1 ; fi ; ORG_NAME=$2 ; shift 2 ;;
        esac ;;
        -u|--user)
        case "$2" in
            -*) echo "-u|--user parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-u|--user parameter requires a value. " ; exit 1 ; fi ; USER_NAME=$2 ; shift 2 ;;
        esac ;;
        -P|--pass-cmd)
        case "$2" in
            -*) echo "-pc|--pass-cmd parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-pc|--pass-cmd parameter requires a value. " ; exit 1 ; fi ; PASSWORD_CMD=$2 ; shift 2 ;;
        esac ;;
        -p|--pass)
        case "$2" in
            -*) echo "-p|--pass parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-p|--pass parameter requires a value. " ; exit 1 ; fi ; PASSWORD=$2 ; shift 2 ;;
        esac ;;
        -b|--bearer-token)
        case "$2" in
            -*) echo "-b|--bearer-token parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-b|--bearer-token parameter requires a value. " ; exit 1 ; fi ; BEARER_TOKEN=$2 ; shift 2 ;;
        esac ;;
        -t|--retry)
        case "$2" in
            -*) echo "-t|--retry parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-t|--retry parameter requires a value. " ; exit 1 ; fi ; MAX_RETRY=$2 ; shift 2 ;;
            esac ;;
        -l|--bylayer)
        case "$2" in
            -*) echo "-l|--bylayer parameter requires a value. " ; exit 1 ;;
            true)  LAYER_MODE="true";  shift 2 ;;
            false) LAYER_MODE="false"; shift 2 ;;
            *)     echo "invalid value for -l|--bylayer"; exit 1 ;;
        esac ;;
        -c|--concurrency)
        case "$2" in
            -*) echo "-c|--concurrency parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-c|--concurrency parameter requires a value. " ; exit 1 ; fi ; CONCURRENCY=$2 ; shift 2 ;;
        esac ;;
        -w|--overwrite)
        case "$2" in
            -*) echo "-w|--overwrite parameter requires a value. " ; exit 1 ;;
            true)  OVERWRITE="true";  shift 2 ;;
            false) OVERWRITE="false"; shift 2 ;;
            *)     echo "invalid value for -w|--overwrite"; exit 1 ;;
        esac ;;
        -k|--chunk-size)
        case "$2" in
            -*) echo "-k|--chunk-size parameter requires a value. " ; exit 1 ;;
            *)  if [[ -z $2 ]] ; then echo "-k|--chunk-size parameter requires a value. " ; exit 1 ; fi ; CHUNK_SIZE_THRESHOLD=$2 ; shift 2 ;;
        esac ;;
        -y|--yes)
            CONFIRM=true;shift 1;;
        *|-*|-h|--help|/?|help) usage;;
    esac
done

readonly REG_VERSION="v2"
readonly REG_MODULE_BLOB="blobs"
readonly REG_MODULE_MANIFEST="manifests"
readonly REG_MODULE_TAG="tags"
readonly REG_ACTION_UPLOAD="uploads"
readonly REG_ACTION_LIST="list"
readonly NEW_IFS=$'\n'
readonly DEFAULT_IMAGE_BASE_DIR="/var/opt/kubernetes/offline/"

USING_EXT_REGISTRY="false"
NEED_PULL_IMAGE="false"
CURRENTDIR=$(cd "$(dirname "$0")";pwd)

IMAGE_BASE_DIR=${IMAGE_BASE_DIR:-${DEFAULT_IMAGE_BASE_DIR}}
MAX_RETRY=${MAX_RETRY:-"5"}
LAYER_MODE=${LAYER_MODE:-"true"}
CONFIRM=${CONFIRM:-"false"}
REGISTRY_BASE=${REGISTRY_BASE:-"localhost:5000"}
ORG_NAME=${ORG_NAME:-""}
CONCURRENCY=${CONCURRENCY:-"1"}
OVERWRITE=${OVERWRITE:-"false"}
USER_NAME=${USER_NAME:-""}
PASSWORD=${PASSWORD:-""}
PASSWORD_CMD=${PASSWORD_CMD:-""}
BEARER_TOKEN=${BEARER_TOKEN:-""}
USER_PROVIDE_REGISTRY=${USER_PROVIDE_REGISTRY:-"false"}
TMP_DIR=${TMP_DIR:-"$CURRENTDIR"}
LOG_FILE="${TMP_DIR}/uploadimages-`date "+%Y%m%d%H%M%S"`.log"
CHUNK_SIZE_THRESHOLD=${CHUNK_SIZE_THRESHOLD:-"50000000"} #50M

PID_ARRAY=()
BASICAUTH=""
AUTH_TYPE=""
AUTH_BASE=""
AUTH_SERVICE=""
CURL_SECURE_OPT="-k "
CURL_NOPROXY_OPT=""
FAIL_FILE=""
SUCCESS_FILE=""
LAYER_REC_FILE=""
LAYER_FAIL_FILE=""
TOKEN_TYPE="" #for bearer auth type, some registry return token, some return access_token, some return both

write_log() {
    local level=$1
    local msg=$2
    local exitCode=1
    local timestamp=$(date --rfc-3339='ns')
    timestamp=${timestamp:0:10}"T"${timestamp:11}
    if [[ ! -z $3 ]] ; then
        exitCode=$3
    fi
    case $level in
        debug) #debug level is dedicated for write to logfile,not to stdout
            echo -e "${timestamp} DEBUG $msg  " >> $LOG_FILE ;;
        info|warn|error)
            echo -e "$msg" && echo -e "${timestamp} `echo $level|tr [:lower:] [:upper:]` $msg  " >> $LOG_FILE ;;
        begin)
            echo -e "$msg\c"
            echo -e "${timestamp} INFO $msg \c" >> $LOG_FILE ;;
        end)
            echo "$msg"
            echo "$msg" >> $LOG_FILE ;;
        fatal)
            echo -e "$msg. \n Please refer to $LOG_FILE for more detail. "
            echo -e "${timestamp} FATAL $msg  " >> $LOG_FILE
            exit ${exitCode}
            ;;
        *)
            echo -e "$msg"
            echo -e "${timestamp} INFO $msg  " >> $LOG_FILE ;;
    esac
}

padSlash(){
    local path=$1
    if [ -n "$path" -a "${path:$((-1))}" != "/" ] ; then
        path="$path/"
    fi
    echo $path
}

isInArray(){
    local target=$1
    local array=$2
    array=( ${array[@]} )

    local found="false"
    for e in ${array[@]} ;
    do
        if [ "$e" == "$target" ] ; then
            found="true"
            break
        fi
    done
    echo $found
}

releaseLockFile(){
    if [[ -f "$LOCK_FILE" ]] && [[ "$(cat $LOCK_FILE)" = "$$" ]] ; then 
        rm -f $LOCK_FILE
    fi
}
makeSingleton(){
    if [[ -f "$LOCK_FILE" ]] ; then
        write_log "error" "Error: one instance is already running and only one instance is allowed at a time. "
        write_log "error" "Check to see if another instance is running."
        write_log "fatal" "If the instance stops running, delete $LOCK_FILE file."
    else
        echo "$$" > $LOCK_FILE
    fi
}
shellSemInit(){
    local value=$1
    mkfifo mulfifo
    exec 1000<>mulfifo
    rm -rf mulfifo
    for ((n=1;n<=${value};n++))
    do
            echo >&1000
    done
}
shellSemWait(){
    read -u1000
}
shellSemPost(){
    echo >&1000
}
shellSemDestroy(){
    exec 1000>&-
    exec 1000<&-
}
killTasks(){
    for pid in ${PID_ARRAY[@]} ; do
        kill -9 $pid 2>/dev/null
    done
}
getMaxConcurrency(){
    local cpuNum=$(cat /proc/cpuinfo 2>/dev/null |grep "processor"|sort -u|wc -l)
    if [[ $cpuNum -le 1 ]] || [[ -z "$cpuNum" ]];then
        echo "1"
    else
        echo $((cpuNum/2))
    fi
}
taskClean(){
    killTasks
    releaseLockFile
    shellSemDestroy
    stty $old
    rm -f ${SUCCESS_FILE}
    rm -f ${FAIL_FILE}
    rm -f ${LAYER_REC_FILE}
    rm -f ${LAYER_FAIL_FILE}
    local image_dir=$(padSlash ${IMAGE_BASE_DIR})
    rm -f ${image_dir}*.tmp*
}
checkCommand(){
    local cmd=$1
    res=$( whereis $cmd > /dev/null 2>& 1; echo $? )
    if [ $res -ne 0 ] ; then
        write_log "fatal" "$cmd not found in PATH($PATH)"
    fi
}
checkFile(){    #check if $file exist under $dir
    local dir=$1
    local file=$2
    dir=$(padSlash $dir)
    if [ -f "$dir$file" ] ; then
        echo "true"
    else
        echo "false"
    fi
}
checkLocalhost(){
    if [ $(cat /etc/hosts | grep -v "^\s*#" | grep "::1" | wc -l) -ne 0 ];then
        write_log "fatal" "Error: localhost is interpreted as IPv6 address. Please comment out the \"::1\" line in /etc/hosts"
    fi
}

preCheck(){
    checkCommand curl
    checkCommand jq
}
readLoginInfo() {
    local retry_time=$1;shift
    local user_tmp=""
    local need_input_password="false"
    if [ -z "$USER_NAME" ];then
        read -p "Username:" USER_NAME
        need_input_password="true"
    else
        if [[ $retry_time -gt 0 ]];then #user have provide username and password
            read -p "Username(${USER_NAME})" user_tmp
            if [ -n "$user_tmp" ];then  #use the name in ()
                USER_NAME=$user_tmp
            fi
            need_input_password="true"
        fi
    fi

    if [ -z "$PASSWORD" ] || [ "$need_input_password" == "true" ];then
        stty -echo
        read -p "Password:" PASSWORD
        stty $old
        echo ""
    fi
}

refreshBasicAuth() {
    if [ -n "$PASSWORD_CMD" ];then
        PASSWORD=$(eval ${PASSWORD_CMD})
        BASICAUTH="$USER_NAME:$PASSWORD"
    fi
}

contactRegistryByDocker(){
    local result=125
    if [[ -z "${USER_NAME}" ]] && [[ -z "${PASSWORD}" ]];then  #no credential provided, fill the credentials with random num in case the registry support anonymous uploading
        USER_NAME=$RANDOM; PASSWORD=$RANDOM
    fi
    for((i=0;i<$MAX_RETRY;i++));do
        if [[ $(docker login -u ${USER_NAME} -p ${PASSWORD} ${REGISTRY_BASE} >>${LOG_FILE} 2>&1; echo $?) == 0 ]];then
            result=0
            break
        else
            readLoginInfo $i
        fi
    done
    return $result
}

contactRegistryByCurl(){
    local result=125
    local scheme="" token="" status_code="" curl_cmd="" http_resp=""

    #step 1. intentify the protocal scheme
    for scheme in "https://" "http://" ; do
        http_resp=$(curl --connect-timeout 20 -s -w %{http_code} ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/)
        status_code=${http_resp:0-3}
        case "$status_code" in 
            200)
                if [ $(echo -e "$http_resp" | grep "blocked" | wc -l) -ne 0 ];then #special handling for docker hub
                    continue
                else
                    AUTH_TYPE=""; AUTH_BASE=""; AUTH_SERVICE=""; result=0; break
                fi
                ;;
            401) 
                AUTH_BASE=$(curl    -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/ | grep "realm" | cut -d = -f2 | cut -d , -f1 | tr -d ["\" \r"])
                AUTH_TYPE=$(curl    -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/ | grep "realm" | cut -d = -f1 | cut -d ' ' -f2)
                AUTH_SERVICE=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${scheme}${REGISTRY_BASE}/v2/ | grep "realm" | cut -d , -f2 | cut -d = -f2| tr -d ["\" \r"])  
                AUTH_SERVICE=${AUTH_SERVICE// /%20} #escape space
                result=1
                break
                ;;
            *) ;;
        esac
    done
    REGISTRY_BASE=${scheme}${REGISTRY_BASE}

    #step 2. check if the credential is correct
    if [[ $result -eq 1 ]];then
        for((i=0;i<$MAX_RETRY;i++));do
            if [[ -z "$USER_NAME" ]] && [[ -z "$PASSWORD" ]];then
                BASICAUTH=""
            else
                BASICAUTH="$USER_NAME:$PASSWORD"
            fi  
            case "$AUTH_TYPE" in
            Basic) #if basic auth, and not credential needed, it is same as anonymous auth
                token=$(echo -n "$BASICAUTH" | base64 -w0);;
            Bearer)
                if [ -z "$BEARER_TOKEN" ];then
                    local auth_opt="" 
                    if [ -n "$BASICAUTH" ];then
                        auth_opt="-u $BASICAUTH"
                    fi
                    curl_cmd="curl -s ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} $auth_opt \"${AUTH_BASE}?service=${AUTH_SERVICE}\""
                    token=$(eval $curl_cmd | jq --raw-output '.token?')
                    TOKEN_TYPE="token"
                    if [ "$token" == "null" ];then
                        token=$(eval $curl_cmd | jq --raw-output '.access_token?')
                        TOKEN_TYPE="access_token"
                    fi
                else
                    token=$BEARER_TOKEN
                fi
                ;;
            *);;
            esac
            status_code=$(curl -s -w %{http_code} ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -H "Authorization: $AUTH_TYPE $token" "$REGISTRY_BASE/v2/")
            status_code=${status_code:0-3}
            if [ "$status_code" == "200" ];then
                result=0
                break
            else
                write_log "error" "Failed to login to $REGISTRY_BASE, please make sure your user name, password and network/proxy configuration are correct."
                write_log "info" "Retrying contacting $REGISTRY_BASE ..."
                readLoginInfo $i
            fi
        done
    fi
    return $result
}

contactRegistry(){
    local reg_host
    if [[ "$REGISTRY_BASE" =~ "://" ]];then  #if user provide registry with http/https scheme, remove it
        REGISTRY_BASE=${REGISTRY_BASE#*://}
    fi
    reg_host=$REGISTRY_BASE
    write_log "info" "Contacting Registry: $reg_host ..."
    local result
    if [[ "$LAYER_MODE" == "false" ]];then
        contactRegistryByDocker
    else
        contactRegistryByCurl
    fi

    if [[ $? -eq 0 ]];then
        write_log "info" "Contacting Registry: $reg_host OK"
    else
        write_log "info" "Contacting Registry: $reg_host FAILED"
        write_log "fatal" "Failed to login to $reg_host, please make sure your user name, password and network/proxy configuration are correct."
    fi
    write_log "debug" "IMAGE_BASE_DIR: $IMAGE_BASE_DIR, REGISTRY_BASE: $REGISTRY_BASE, ORG_NAME:$ORG_NAME, USING_EXT_REGISTRY:$USING_EXT_REGISTRY, AUTH_TYPE: $AUTH_TYPE,  AUTH_BASE: $AUTH_BASE,  AUTH_SERVICE: $AUTH_SERVICE"    
}
findLatestDir(){
    local base_dir=$1;shift
    local dirs=$(ls -t $base_dir 2>>$LOG_FILE | xargs)  #sorted by timestamp
    local latest_dir=""
    for item in ${dirs[@]}; do
        #folder name convention: images_yyyymmddhhmmss, 14 char and a null-terminate char
        local prefix=${item%%_*}
        local sufix=${item#*_}
        if [[ -d $item ]] && [ "$prefix" != "images" ] || [ $(echo $sufix | wc -c 2>/dev/null) -ne 15 ];then
            continue
        fi
        if [[ "$item" > "$latest_dir" ]];then
            latest_dir=$item
        fi
    done
    echo $latest_dir
}
init(){
    local answer
    if [ "$CONFIRM" == "false" ]; then
        for((i=0;i<$MAX_RETRY;i++)); do
            read -p "Are you sure to continue? (Y/N): " answer
            answer=$(echo "$answer" | tr '[A-Z]' '[a-z]')
            case "$answer" in 
                y|yes ) break;;
                n|no )  write_log "fatal" "Uploading process QUIT." ;;
                * )     write_log "warn" "Unknown input, Please input Y or N";;
            esac
            if [[ $i -eq $MAX_RETRY ]];then
                write_log "fatal" "error input for $MAX_RETRY times Uploading process QUIT." 
            fi
        done
    fi

    export PATH=$PATH:$CURRENTDIR:$CURRENTDIR/../bin  #in some case,jq is under the pwd but can not be found in $PATH

    if [[ ! -d $TMP_DIR ]]; then
        mkdir -p $TMP_DIR
    fi

    
    if [[ "$REGISTRY_BASE" =~ "gcr.io" ]];then
        CHUNK_SIZE_THRESHOLD=100000000000
    fi

    local max_cucurrency=$(getMaxConcurrency)
    if [[ $CONCURRENCY -le 0 ]];then
        CONCURRENCY=1
    elif [[ $CONCURRENCY -gt $max_cucurrency ]];then
        CONCURRENCY=$max_cucurrency
    fi
    write_log "info" "The concurrency number is constrained to 1-$max_cucurrency, and current concurrency number is: $CONCURRENCY"
    IMAGE_BASE_DIR=$(padSlash "$IMAGE_BASE_DIR")
    if [[ ! -d ${IMAGE_BASE_DIR} ]] ; then
        write_log "fatal" "${IMAGE_BASE_DIR} not exist"
    fi
    if [ "$IMAGE_BASE_DIR" == "$DEFAULT_IMAGE_BASE_DIR" ];then
        local latest_dir=$(findLatestDir "$IMAGE_BASE_DIR")
        IMAGE_BASE_DIR=${IMAGE_BASE_DIR}${latest_dir}
    fi
    SUCCESS_FILE="${IMAGE_BASE_DIR}/success-`date "+%Y%m%d%H%M%S"`"
    FAIL_FILE="${IMAGE_BASE_DIR}/fail-`date "+%Y%m%d%H%M%S"`"
    LOCK_FILE="${IMAGE_BASE_DIR}/.upload-lock"
    LAYER_REC_FILE="${IMAGE_BASE_DIR}/layer-`date "+%Y%m%d%H%M%S"`"
    LAYER_FAIL_FILE="${IMAGE_BASE_DIR}/layer-fail-`date "+%Y%m%d%H%M%S"`"

    preCheck
    makeSingleton

    if [[ "$USER_PROVIDE_REGISTRY" == "false" ]] && [[ "$SUITE_REGISTRY" != "localhost:5000" ]];then
        USING_EXT_REGISTRY="true"
    fi
    if [[ "$REGISTRY_BASE" =~ "localhost:5000" ]];then
        CURL_NOPROXY_OPT="--noproxy localhost"
        NEED_PULL_IMAGE="true"
        checkCommand "docker"
        checkLocalhost
    fi

    if [[ "$REGISTRY_BASE" =~ "localhost:5000" ]] || [[ "$LAYER_MODE" == "false" ]];then
        checkCommand "docker"
    fi

    if [[ -z "$ORG_NAME" ]]; then #when push cdf phase-1 images,$ORG_NAME is set by cli option
        if [ -n "$REGISTRY_ORGNAME" ];then #script is running in cdf env
            ORG_NAME=$REGISTRY_ORGNAME
        else #script is running in cdf env, and user miss the option
            local org_temp
            read -p "Organization name is empty,please provide it:" org_temp
            ORG_NAME=$org_temp
        fi
        
    fi
    refreshBasicAuth
}
getAuthToken(){
    local image_name=$1;shift
    local org_name=$1;shift
    local curl_cmd="" token=""
    if [ -z "$AUTH_TYPE" ];then
        token=""
    elif [ -n "$BEARER_TOKEN" ];then
        token=$BEARER_TOKEN
    else
        refreshBasicAuth
        if [ "$AUTH_TYPE" == "Basic" ]; then
            token=$(echo -n "$BASICAUTH" | base64 -w0)
        else
            local basic_auth=""
            if [ -n "$BASICAUTH" ];then
                basic_auth="-u $BASICAUTH"
            fi
            local repo
            if [ -z "$org_name" ];then
                repo=${image_name}
            else
                repo=${org_name}/${image_name}
            fi
            local query_string="?service=${AUTH_SERVICE}&scope=repository:${repo}:push,pull"
            write_log "debug" "curl -s ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -u *** ${AUTH_BASE}${query_string}"
            token=$(curl -s ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${basic_auth} ${AUTH_BASE}${query_string} 2>>$LOG_FILE | jq -r ".${TOKEN_TYPE}?")
            #write_log "debug" "get token=$token"
        fi
    fi 
    echo  $token
}

getRepositoryTaglist(){
    local reg_host=$(padSlash $1);shift
    local org_name=$1;shift
    local image_name=$1;shift
    write_log "debug" "Begin to get image taglist[host=$reg_host,org_name=$org_name,image=$image_name]"

    local response
    local token=$(getAuthToken "$image_name" "$org_name")
    local url=${reg_host}${REG_VERSION}/${org_name}/${image_name}/${REG_MODULE_TAG}/${REG_ACTION_LIST}
    write_log "debug" "Get image taglist with command: curl -s -X GET ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} ${reg_host}${registry_version}${org_name}${image_name}${registry_module_tag}${registry_action_list}"
    if [ -z "$token" ];then
        response=$(curl -s -X GET ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} $url)
    else
        response=$(curl -s -X GET ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -H "Authorization: $AUTH_TYPE $token" $url)
    fi
    echo -e "$response" >>$LOG_FILE
    local result=$(echo $response | jq -r '.tags[]?' 2>/dev/null)
    if [ -z "$result" ]; then
        write_log "debug" "Get image taglist[host=$reg_host,org_name=$org_name,image=$image_name]:failed"
    else
        write_log "debug" "Get image taglist[host=$reg_host,org_name=$org_name,image=$image_name]:OK"
    fi
    echo $result
}

getBlobUploadLocation(){
    local reg_host=$(padSlash $1);shift
    local org_name=$1;shift
    local image_name=$1;shift
    write_log "debug" "Begin to get upload location[org_name=$org_name,image=$image_name]"

    local location res url
    local token=$(getAuthToken "$image_name" "$org_name")
    if [ -z "$org_name" ];then
        url=${reg_host}${REG_VERSION}/${image_name}/${REG_MODULE_BLOB}/${REG_ACTION_UPLOAD}/
    else
        url=${reg_host}${REG_VERSION}/${org_name}/${image_name}/${REG_MODULE_BLOB}/${REG_ACTION_UPLOAD}/
    fi
    
    
    #as getBlobUploadLocation is part of uploadBlob, we not implement retry any more
    write_log "debug" "Get upload location with command: curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X POST -H \"Content-Length: 0\" $url"
    if [ -z "$token" -o "$token" = "null" ];then
        res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X POST -H "Content-Length: 0" $url 2>> $LOG_FILE)
    else
        res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X POST -H "Content-Length: 0" -H "Authorization: $AUTH_TYPE $token" $url 2>> $LOG_FILE)
    fi        
    echo -e "$res" >>$LOG_FILE
    location=$(echo -e "$res" | grep "Location" | cut -d ' ' -f 2)

    if [ -n "$location" ] ; then
        write_log "debug" "Get upload location[org_name=$org_name,image=$image_name]:OK"
        if [[ ! "$location" =~ "http" ]];then  #for Azure registry, it return url start with /v2/
            location="$REGISTRY_BASE$location"
        fi
        echo "${location}"
    else
        write_log "debug" "Get upload location[org_name=$org_name,image=$image_name]:failed"
        echo ""
    fi
}

uploadBlob(){
    local reg_host=$(padSlash $1);shift
    local org_name=$1;shift
    local image_name=$1;shift
    local blob=$1;shift
    local size=$1;shift
    local digest=$1;shift
    write_log "debug" "Begin to upload layer[layer=$blob,size=$size,digest=$digest]"
    local res location full_location chunk_size token
    local result="failed"

    for((i=0;i<$MAX_RETRY;i++)); do
        location=$(getBlobUploadLocation "$reg_host" "$org_name" "$image_name" | tr -d ["\r"] | tr -d ["\n"])
        if [ -z "$location" ]; then #not get location, failed
            continue
        fi

        local chunk_array
        local path=${blob%/*}
        if [[ $size -lt $CHUNK_SIZE_THRESHOLD ]];then
            chunk_array=(${blob##*/} "")
        else
            local path=${blob%/*}
            local digest_x=${digest#*:}
            local is_splited=$(ls $path 2>>$LOG_FILE | grep "${digest_x}.tmp" | wc -l)
            if [[ $is_splited -eq 0 ]] && [[ $i -eq 0 ]]; then  #only when not split before will we split the file,as split big file is time consumed task
                split -b $CHUNK_SIZE_THRESHOLD $blob "${path}/${digest_x}.tmp" 2>>$LOG_FILE
            fi
            chunk_array=($(ls $path 2>>$LOG_FILE | grep "${digest_x}.tmp" | xargs))
            chunk_array=(${chunk_array[@]})
        fi
        local chunk_array_size=${#chunk_array[@]}
        local chunk chunk_size=0 range_start=0 range_end= 
        for((j=0;j<$(((chunk_array_size-1)));j++));do
            chunk="${path}/${chunk_array[$j]}"
            chunk_size=$(stat -c "%s" $chunk 2>>$LOG_FILE)
            range_end=$(((range_start+chunk_size-1)))
            token=$(getAuthToken "$image_name" "$org_name")
            write_log "debug" "Upload layer with command:curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X PATCH -T $chunk -H \"chunck:Content-Length: $chunk_size\" -H \"Content-Range: ${range_start}-${range_end}\" -H \"Content-Type: application/octet-stream\" <auth> $location "
            if [ -z "$token" ];then
                res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X PATCH -T "$chunk" -H "chunck:Content-Length: $chunk_size" -H "Content-Range: ${range_start}-${range_end}" -H "Content-Type: application/octet-stream" "$location" 2>>$LOG_FILE)
            else
                res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X PATCH -T "$chunk" -H "chunck:Content-Length: $chunk_size" -H "Content-Range: ${range_start}-${range_end}" -H "Content-Type: application/octet-stream" -H "Authorization: $AUTH_TYPE $token" "$location" 2>>$LOG_FILE)
            fi            
            echo -e "$res" >>$LOG_FILE
            location=$(echo "$res" | grep "Location" | cut -d ' ' -f 2 | tr -d ["\r"] | tr -d ["\n"])
            if [ -z "$location" ]; then #not get location, failed
                break
            fi
            if [[ ! "$location" =~ "http" ]];then  #for Azure registry, it return url start with /v2/
                location="$REGISTRY_BASE$location"
            fi
            range_start=$(((range_start+chunk_size)))
        done
        if [[ "$location" =~ "?" ]];then
            full_location="${location}&digest=${digest}"
        else
            full_location="${location}?digest=${digest}"
        fi
        
        token=$(getAuthToken "$image_name" "$org_name")
        if [ -z "${chunk_array[$(((chunk_array_size-1)))]}" ];then  #last chunk has no content
            write_log "debug" "Upload layer with command:curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT}  -X PUT -H \"Content-Length: 0\"  -H \"Content-Type: application/octet-stream\" ${full_location} 2>>$LOG_FILE"
            if [ -z "$token" ];then
                res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT}  -X PUT -H "Content-Length: 0"  -H "Content-Type: application/octet-stream" ${full_location} 2>>$LOG_FILE)
            else
                res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT}  -X PUT -H "Content-Length: 0"  -H "Content-Type: application/octet-stream" -H "Authorization: $AUTH_TYPE $token" ${full_location} 2>>$LOG_FILE)
            fi
        else
            chunk="${path}/${chunk_array[$(((chunk_array_size-1)))]}"
            chunk_size=$(stat -c "%s" $chunk 2>>$LOG_FILE)
            range_end=$(((range_start+chunk_size-1)))
            write_log "debug" "Upload layer with command:curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X PUT -T \"${chunk}\" -H \"Content-Length: ${chunk_size}\" -H \"Content-Range: ${range_start}-${range_end}\" -H \"Content-Type: application/octet-stream\" ${full_location} 2>>$LOG_FILE"
            if [ -z "$token" ];then
                res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X PUT -T "${chunk}" -H "Content-Length: ${chunk_size}" -H "Content-Range: ${range_start}-${range_end}" -H "Content-Type: application/octet-stream" ${full_location} 2>>$LOG_FILE)
            else
                res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X PUT -T "${chunk}" -H "Content-Length: ${chunk_size}" -H "Content-Range: ${range_start}-${range_end}" -H "Content-Type: application/octet-stream" -H "Authorization: $AUTH_TYPE $token" ${full_location} 2>>$LOG_FILE)
            fi
        fi
        
        echo -e "$res" >> $LOG_FILE
        res=$(echo -e "$res" | grep "201 Created")
        if [ -n "$res" ] ; then
            result="success"
            break
        fi
        write_log "debug" "Upload layer[layer=$blob,size=$size,digest=$digest]:failed, retry in 2 seconds"
	    sleep 2
    done

    if [ "$result" == "success" ] ; then
        write_log "debug" "Upload layer[layer=$blob,size=$size,digest=$digest]:OK"
    else
        write_log "debug" "Upload layer[layer=$blob,size=$size,digest=$digest]:failed"
        echo $digest >> $LAYER_FAIL_FILE
    fi
    shellSemPost
}

crossRepositoryBlobMount(){
    local reg_host=$(padSlash $1);shift
    local org_name=$1;shift
    local image_name=$1;shift
    local digest=$1;shift
    local cross_repo=$1;shift
    write_log "debug" "Begin to layer-reference[org_name=$org_name,src_image=$image_name,digest=$digest,des_image=$cross_repo]"

    local url res
    local token=$(getAuthToken "$image_name" "$org_name")
    if [ -z "$org_name" ];then
        url="${reg_host}${REG_VERSION}/${image_name}/${REG_MODULE_BLOB}/${REG_ACTION_UPLOAD}/?mount=${digest}&from=${cross_repo}"
    else
        url="${reg_host}${REG_VERSION}/${org_name}/${image_name}/${REG_MODULE_BLOB}/${REG_ACTION_UPLOAD}/?mount=${digest}&from=${cross_repo}"
    fi

    for((i=0;i<$MAX_RETRY;i++)); do
        write_log "debug" "Layer reference with command: curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X POST -H \"Content-Length: 0\" ${url}"
        if [ -z "$token" ];then
            res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X POST -H "Content-Length: 0" ${url} 2>>$LOG_FILE)
        else
            res=$(curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X POST -H "Content-Length: 0" -H "Authorization: $AUTH_TYPE $token" ${url} 2>>$LOG_FILE)
        fi
        echo -e "$res" >> $LOG_FILE
        res=$(echo -e "$res" | grep "201 Created")
        if [ -n "$res" ] ; then
            break
        fi
        write_log "debug" "Layer-referencing[org_name=$org_name,src_image=$image_name,digest=$digest,des_image=$cross_repo]: failed, retry in 2 seconds"
	    sleep 2
    done

    if [ -n "$res" ] ; then
        write_log "debug" "Layer-reference[org_name=$org_name,src_image=$image_name,digest=$digest,des_image=$cross_repo]: OK"
        echo "success"
    else
        write_log "debug" "Layer-reference[org_name=$org_name,src_image=$image_name,digest=$digest,des_image=$cross_repo]: failed"

        echo "failed"
    fi
}

putManifest(){
    local reg_host=$(padSlash $1);shift
    local org_name=$1;shift
    local image_name=$1;shift
    local image_tag=$1;shift
    local manifest_file=$1;shift
    
    write_log "debug" "Begin to upload manifest[org_name=$org_name,image_name=$image_name,image_tag=$image_tag]"

    local res curl_cmd http_resp token url
    local manifest_file=$(padSlash ${IMAGE_BASE_DIR})$manifest_file
    local file_size=$(stat -c "%s" $manifest_file 2>>$LOG_FILE)
    if [ -z "$org_name" ];then
        url=${reg_host}${REG_VERSION}/${image_name}/${REG_MODULE_MANIFEST}/${image_tag}
    else
        url=${reg_host}${REG_VERSION}/${org_name}/${image_name}/${REG_MODULE_MANIFEST}/${image_tag}
    fi

    for((i=0;i<$MAX_RETRY;i++)); do
        token=$(getAuthToken "$image_name" "$org_name")
        write_log "debug" "Upload manifest with command: curl -s -I ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -X PUT -T \"$manifest_file\" -H \"Content-Type:application/vnd.docker.distribution.manifest.v2+json\" \"${url}\""
        if [ -z "$token" ];then
            http_resp=$(curl -w %{http_code} ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -H "chunck:Content-Length: $file_size" -X PUT -T "$manifest_file" -H "Content-Type: application/vnd.docker.distribution.manifest.v2+json" "${url}" 2>>$LOG_FILE )
        else
            http_resp=$(curl -w %{http_code} ${CURL_NOPROXY_OPT} ${CURL_SECURE_OPT} -H "chunck:Content-Length: $file_size" -X PUT -T "$manifest_file" -H "Content-Type: application/vnd.docker.distribution.manifest.v2+json" -H "Authorization: $AUTH_TYPE $token" "${url}" 2>>$LOG_FILE)
        fi
        echo -e "$http_resp" >> $LOG_FILE
        local status_code=${http_resp:0:3}
        if [[ "$status_code" == 20* ]]; then
            res="success"
            break
        fi

        write_log "debug" "Upload manifest[org_name=$org_name,image_name=$image_name,image_tag=$image_tag]:failed,retry in 2 seconds"
	    sleep 2
    done  

    if [ -n "$res" ] ; then
        write_log "debug" "Upload manifest[org_name=$org_name,image_name=$image_name,image_tag=$image_tag]: OK"
        echo "success"
    else
        write_log "debug" "Upload manifest[org_name=$org_name,image_name=$image_name,image_tag=$image_tag]: failed"
        echo "failed"
    fi
}

printProcessInfo(){
    local total=$1;shift
    local reg_host=$(padSlash $1);shift
    local org_name=$(padSlash $1);shift
    local image_name=$1;shift
    local image_tag=$1;shift
    local result=$1;shift

    if [[ "$reg_host" =~ "://" ]];then
        reg_host=${reg_host#*://}
    fi

    case "$result" in
        "OK"|"ALREADY UPLOADED") echo "$org_name/$image_name/$image_tag" >> ${SUCCESS_FILE};;
        "FAILED") echo "$org_name/$image_name/$image_tag" >> ${FAIL_FILE};;
        *) echo "$org_name/$image_name/$image_tag" >> ${FAIL_FILE};;
    esac

    local index
    local fail_cnt=$(cat ${FAIL_FILE}   2>/dev/null | wc -l)
    local succ_cnt=$(cat ${SUCCESS_FILE} 2>/dev/null | wc -l)
    let index=${fail_cnt}+${succ_cnt}
    write_log "info" "Uploading image [${index}/${total}] ${reg_host}${org_name}$image_name:$image_tag ... $result"
}
printProcessInfoBegin(){
    local index=$1;shift
    local total=$1;shift
    local reg_host=$(padSlash $1);shift
    local org_name=$(padSlash $1);shift
    local image_name=$1;shift
    local image_tag=$1;shift

    rm -rf $LAYER_FAIL_FILE
    PID_ARRAY=()  #clear PID_ARRAY
    if [[ "$reg_host" =~ "://" ]];then
        reg_host=${reg_host#*://}
    fi
    write_log "begin" "Upload image [${index}/${total}] ${reg_host}${org_name}$image_name:$image_tag ... "
}
printProcessInfoEnd(){
    local result=$1;shift
    write_log "end" "$result"
    if [ "$result" = "FAILED" ]; then
        echo "failed" >> $FAIL_FILE
    fi    
}
getUploadedBlobs(){
    local IFS="$NEW_IFS"
    local layers=$(cat $LAYER_REC_FILE 2>/dev/null)
    unset IFS

    echo ${layers[*]}
}
addUploadedBlobs(){
    local check_sum=$1;shift
    local org_name=$(padSlash $1);shift
    local image_name=$1;shift

    local repo=${org_name}${image_name}

    echo "${check_sum},${repo}" >> $LAYER_REC_FILE
}
getCrossMountRepository(){
    local check_sum=$1;shift
    local uploaded_blobs=$1;shift

    local repository=""
    for blob in ${uploaded_blobs[@]} ; do
        local chk=${blob%%,*}
        local repo=${blob##*,}
        if [ "$chk" == "$check_sum" ] ; then
            repository=$repo
            break;
        fi
    done
    echo $repository
}

pushOneV2Image(){
    local reg_host=$1;shift
    local reg_tags=$1;shift
    local config_file=$1;shift
    local layers=$1;shift
    local index=$1;shift
    local total=$1;shift
    write_log "debug" "Begin to push image[image=$reg_tags]"

    local res new_org_name=""

    reg_tags=( ${reg_tags[@]} )
    layers=( ${layers[@]} )

    for repo_tag in ${reg_tags[@]}; do
        local old_org_name=""
        if [[ "$repo_tag" =~ "/" ]]; then
            old_org_name=${repo_tag%%/*}
        fi
        if [ -n "$old_org_name" ];then
            new_org_name=$ORG_NAME
        fi
        
        local name_tag=${repo_tag##*/}
        local image_name=${name_tag%:*}
        local image_tag=${repo_tag##*:}
        printProcessInfoBegin "$index" "${total}" "$reg_host" "$new_org_name" "$image_name" "$image_tag"

        #requestToken "$image_name" "$new_org_name"

        local is_exist
        if [[ "$image_name" =~ "jdbc-drivers-container" ]];then #force to upload jdbc
            is_exist="false"
        else
            if [ "$OVERWRITE" = "true" ];then
                is_exist="false"
            else
                local tag_list=$(getRepositoryTaglist "$reg_host" "$new_org_name" "$image_name")
                is_exist=$(isInArray "$image_tag" "${tag_list[*]}")
            fi
        fi
        
        if [ "$is_exist" == "true" ]; then
	        write_log "debug" "Pushing image[image=$reg_tags]:tag already exist in taglist"
            printProcessInfoEnd  "ALREADY UPLOADED"
        else
            layers=( $config_file "${layers[@]}" )   #treat config file as layer
            local layer_info
            local i=0 fail_cnt=0
            shellSemInit ${CONCURRENCY}
            for blob in ${layers[@]}; do
                local blob_path="$(padSlash ${IMAGE_BASE_DIR})${blob}"

                local check_sum=${blob%%.*}
                check_sum="sha256:${check_sum}"
                local size=$(stat -c "%s" $blob_path 2>>$LOG_FILE)

                layer_info[$i]="${check_sum}/${size}"
                i=$(( ${i} + 1 ))

                local uploaded_blobs cross_mount_repo
                if [[ "$reg_host" =~ "localhost:5000" ]];then  #we found portus and docker hub not support crossmount,here we only optimize local registry
                    uploaded_blobs=$(getUploadedBlobs)
                    cross_mount_repo=$(getCrossMountRepository "$check_sum" "${uploaded_blobs[*]}")
                else
                    cross_mount_repo=""
                fi
                if [ -n "$cross_mount_repo" ];then  #blob is exist in registry
                    res=$(crossRepositoryBlobMount "$reg_host" "$new_org_name" "$image_name" "$check_sum" "$cross_mount_repo")
                    if [ "$res" == "success" ] ; then
                        write_log "debug" "Skip existed layer:$check_sum"
                    else
                        write_log "debug" "Layer-reference Failed:$check_sum"
                        echo $digest >> $LAYER_FAIL_FILE
                        break
                    fi  
                else
                    fail_cnt=$(cat ${LAYER_FAIL_FILE}   2>/dev/null | wc -l)
                    if [[ $fail_cnt -ne 0 ]]; then
                        break
                    fi
                    shellSemWait
                    uploadBlob "$reg_host" "$new_org_name" "$image_name" "$blob_path" "$size" "$check_sum" &
                    PID_ARRAY=( ${PID_ARRAY[@]} $! )
                fi
            done
            wait
            fail_cnt=$(cat ${LAYER_FAIL_FILE}   2>/dev/null | wc -l)
            if [[ $fail_cnt -ne 0 ]]; then
                printProcessInfoEnd  "FAILED"
                continue   #as images may have multi-tags, we should not return,but continue here
            fi

            #if all layers are uploaded successfully, add  them to LAYER_REC_FILE
            for blob in ${layers[@]}; do
                local check_sum=${blob%%.*}
                check_sum="sha256:${check_sum}"
                addUploadedBlobs "$check_sum" "${new_org_name}" "${image_name}"
            done
            
        
            #put manifest, if image has multi-tags, the layers are actually uploaded only once, but manifest should upload for each tag
            old_org_name=""
            if [[ "$repo_tag" =~ "/" ]]; then
                old_org_name=${repo_tag%%/*}
            fi
            name_tag=${repo_tag##*/}
            image_name=${name_tag%:*}
            image_tag=${repo_tag##*:}

            local manifest_file=${old_org_name}_${image_name}_${image_tag}.manifest

            res=$(putManifest "$reg_host" "$new_org_name" "$image_name" "$image_tag" "$manifest_file")
            if [ "$res" == "success" ] ; then
                write_log "debug" "Upload manifest success"
                printProcessInfoEnd  "OK"
            else
                write_log "debug" "Upload manifest failed"
                printProcessInfoEnd  "FAILED"
            fi
        fi
    done    
}

pushImages(){
    local is_exist=$(checkFile $IMAGE_BASE_DIR "manifest.json")
    if [ "$is_exist" == "false" ]; then
        write_log "error" "\nWarning: manifest.json not found under $IMAGE_BASE_DIR, skip uploading suite images"
        write_log "warn"  "Add \"-l false\" option if image are not in layer form\n"
        return 1
    fi

    local reg_host=$REGISTRY_BASE
    local manifest_file="$(padSlash $IMAGE_BASE_DIR)manifest.json"

    local repo_num=$(cat $manifest_file | jq '.|length')
    if [[ -z "$repo_num" ]] || [[ "$repo_num" == "null" ]] || [[ $repo_num -eq 0 ]];then
        write_log "error" "manifest.json under $IMAGE_BASE_DIR is empty, please check image downloading is successful or not"
        return 1
    fi
    local total=0
    for((i=0;i<$repo_num;i++));do
        num=$(cat $manifest_file | jq '.['${i}'].RepoTags|length')
        let total=total+num
    done

    local manifest_content=$(cat $manifest_file 2>/dev/null)
    local image_array_size=$(echo $manifest_content | jq '. | length')
    if [[ $image_array_size -le 0 ]] ; then
        write_log "warn" "No images found, stop uploading"
        return 0
    fi
    local begin_time=$(date +%s)

    write_log "info" "\n** Uploading suite images"
    for ((index=0;index<$image_array_size;index++));do 

        local config_file=$(echo $manifest_content | jq --raw-output '.['$index'].Config')
        local IFS="$NEW_IFS"
        local repo_tags=$(echo $manifest_content | jq --raw-output '.['$index'].RepoTags[]')
        repo_tags=( $repo_tags )
        local layers=$(echo $manifest_content | jq --raw-output '.['$index'].Layers[]')
        layers=( $layers )
        unset IFS

        if [ -z "$config_file" -o -z "$repo_tags" -o -z "$layers" -o ${#repo_tags[@]} -eq 0 -o ${#layers[@]} -eq 0 ] ; then
            write_log "fatal" "Image manifest info corrupted!"
        fi

        pushOneV2Image "$reg_host" "${repo_tags[*]}" "$config_file" "${layers[*]}" "$(((index+1)))" "$total"
    done
    local end_time=$(date +%s)
    local cost_time=$(($end_time - $begin_time))
    write_log "info" "Upload completed in ${cost_time} seconds."
    return 0
}

pushOneImage(){
    local reg_host=$(padSlash $1);shift
    if [[ "$reg_host" =~ "://" ]];then
        reg_host=${reg_host#*://}
    fi
    local image=$1;shift
    local image_index=$1;shift
    local total=$1;shift
    write_log "debug" "Begin push image[image=$image,$image_index/$total]"

    local repo_dir="${dir}${image_index}/"
    if [[ $(file $image | grep "gzip compressed data" | wc -l) -ne 0 ]];then  #no compressed by gzip
        rm -rf ${repo_dir}
        mkdir -p ${repo_dir}
        tar -x -z -C ${repo_dir} -f ${image}  repositories  >>${LOG_FILE} 2>&1
        local full_name_temp=$(cat ${repo_dir}repositories 2>>${LOG_FILE} | jq 'keys|.[0]')
        local full_name=$(cat ${repo_dir}repositories 2>>${LOG_FILE} | jq -r 'keys|.[0]')
        local tag=$(cat ${repo_dir}repositories 2>>${LOG_FILE} | jq -r ".${full_name_temp}|keys|.[0]")
        rm -rf ${repo_dir}

        local url=""
        local old_org_name=""
        local name=""
        if [[ "$full_name" =~ "/" ]]; then
            url=${full_name%%/*}
            name=${full_name##*/}
            old_org_name=${full_name#*/}
            if [[ "$old_org_name" =~ "/" ]] ;then
                old_org_name=${old_org_name%/*}
            else
                old_org_name=""
            fi
            
        fi

        local new_org_name=""
        if [ -n "$old_org_name" ];then
            new_org_name=$(padSlash "$ORG_NAME")
        fi

        for((i=0;i<${MAX_RETRY};i++));do
            write_log "debug" "docker rmi ${reg_host}${new_org_name}${name}:$tag"
            docker rmi ${reg_host}${new_org_name}${name}:$tag >/dev/null 2>&1
            write_log "debug" "docker load -i $image"
            docker load -i $image >> $LOG_FILE 2>&1
            write_log "debug" "docker tag $full_name:$tag ${reg_host}${new_org_name}${name}:$tag"
            docker tag $full_name:$tag ${reg_host}${new_org_name}${name}:$tag >> $LOG_FILE 2>&1
            write_log "debug" "docker push ${reg_host}${new_org_name}${name}:$tag" 
            docker push ${reg_host}${new_org_name}${name}:$tag >> $LOG_FILE 2>&1
            if [ $? -eq 0 ]; then
                write_log "debug" "docker rmi ${reg_host}${new_org_name}${name}:$tag"
                docker rmi ${reg_host}${new_org_name}${name}:$tag >> $LOG_FILE 2>&1
                break
            else
                write_log "debug" "$image failed, retry in 2 seconds ..."
                sleep 2
            fi
        done
        
        if [ $i -ge ${MAX_RETRY} ]  ; then
            printProcessInfo "${total}" "${reg_host}" "${new_org_name}" "${name}" "$tag" "FAILED"
        else
            printProcessInfo "${total}" "${reg_host}" "${new_org_name}" "${name}" "$tag" "OK"
        fi
    else
        local file_name=${image##*/}
        printProcessInfo "${total}" "${reg_host}" "unknown" "${file_name}" " " "NOT SUPPORT"
    fi
    shellSemPost
}

pushSuiteImages() {
    local is_exist=$(checkFile $IMAGE_BASE_DIR "manifest.json")
    if [ "$is_exist" == "true" ]; then
        write_log "error" "\nWarning: manifest.json found under $IMAGE_BASE_DIR,but \"--bylayer\" option is \"false\", skip uploading suite images \n"
        return 1
    fi    
    write_log "info" "\nNote: Only images compressed by gzip and extented with .tar.gz in its file name are supported\n"

    local IFS="$NEW_IFS"
    local images=$(ls ${IMAGE_BASE_DIR}*.tar.gz 2>>$LOG_FILE)
    images=( ${images[@]} )
    local total=${#images[@]}
    unset IFS
    if [[ $total -le 0 ]];then
        write_log "error" "\nWarning: no images found under $IMAGE_BASE_DIR \n"
        return 1
    fi

    write_log "info" "\n** Uploading suite images from: $IMAGE_BASE_DIR"
    local reg_host=$REGISTRY_BASE
    local begin_time=$(date +%s)
    local image_index=1
    shellSemInit ${CONCURRENCY}
    for im in ${images[@]}; do
        shellSemWait
        pushOneImage $reg_host $im $image_index $total &
        PID_ARRAY=("$PID_ARRAY[@] $!")
        image_index=$(( ${image_index} + 1 ))
    done
    shellSemDestroy
    wait
    local end_time=$(date +%s)
    local cost_time=$(($end_time - $begin_time))
    write_log "info" "Upload completed in ${cost_time} seconds."
    return 0
}

printProcessResult(){
    local result=$1;shift
    local fail_num=0
    local final_result
    if [ -f $FAIL_FILE ]; then
        fail_num=$(cat $FAIL_FILE | wc -l)
    fi
    if [[ $result -eq 0 ]] && [[ $fail_num -eq 0 ]]; then
        write_log "info" "Upload-process successfully completed."
        final_result=0
    else
        write_log "info" "Upload-process completed with errors."
        write_log "info" "Check Username/Password,your account access ability, http/https proxy setting and repo create requirement of your registry before uploading."
        final_result=1
    fi
    write_log "info" "Please refer: $LOG_FILE for more detail"
    return $final_result
}

pullPhase2Images(){
    local property_file="$K8S_HOME/properties/images/phase2_images.properties"
    local server=$REGISTRY_BASE
    if [[ "$server" =~ "://" ]];then
        server=${server#*://}
    fi
    local server=$(padSlash "$server")
    local org_name=$(padSlash "$REGISTRY_ORGNAME")
    items=($(cat ${property_file} | xargs))
    items=(${items[@]})
    for it in ${items[@]}; do
        image=${it##*=}\
        repo=${server}${org_name}$image
        docker pull $repo 1>/dev/null 2>/dev/null &
    done
}

##############MAIN##############
trap 'taskClean; exit' 1 2 3 8 9 14 15 EXIT
old=$(stty -g)
init
if [[ "$USING_EXT_REGISTRY" == "false" ]] ; then
    contactRegistry
    if [[ "$LAYER_MODE" == "false" ]] ; then
        pushSuiteImages
    else
        pushImages
    fi
    result=$?
    printProcessResult "$result"
    result=$?   #final result
    if [[ $result -eq 0 ]] && [[ "$NEED_PULL_IMAGE" == "true" ]];then
        pullPhase2Images
        echo "" #necessary, otherwise the prompt will not show, seens as if the upload hungs.
    fi
else
    write_log "info" "ITOM core platform is redirected to intended external registry, no need to upload!"
fi
exit $result    #exit with return code for those who needed